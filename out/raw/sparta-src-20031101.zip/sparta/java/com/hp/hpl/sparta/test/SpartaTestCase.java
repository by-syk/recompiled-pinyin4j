package com.hp.hpl.sparta.test;

import java.io.*;
import java.net.MalformedURLException;
import java.util.Enumeration;

import junit.framework.TestCase;

import com.hp.hpl.sparta.*;
import com.hp.hpl.sparta.xpath.XPathException;

/**
 * Sparta unit test.
 *

   <blockquote><small> Copyright (C) 2002 Hewlett-Packard Company.
   This file is part of Sparta, an XML Parser, DOM, and XPath library.
   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 2.1 of
   the License, or (at your option) any later version.  This library
   is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE. </small></blockquote>
   @version  $Date: 2002/10/30 23:18:43 $  $Revision: 1.9 $
   @author Eamonn O'Brien-Strain
 */

public class SpartaTestCase extends TestCase {

    public SpartaTestCase(String name) {
        super(name);
    }

    public void setUp() throws DOMException, MalformedURLException {
        doc_ = new Document();

        root_ = new Element("Root");
        doc_.setDocumentElement(root_);

        text_ = new Text("some text");
        root_.appendChild(text_);

        element_ = new Element("Element");
        root_.appendChild(element_);

        element2_ = new Element("Element2");
        root_.appendChild(element2_);

        element2_.setAttribute("a", "p");
        element_.setAttribute("a", "q");

        expectedRootXml_ =
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>";

        testUrl_ = getName();

        log_ = new CountLog();
    }

    public void testNodeGetOwnerDocument() {
        assertTrue(doc_.getOwnerDocument() == null);
        assertTrue(root_.getOwnerDocument() == doc_);
        assertTrue(text_.getOwnerDocument() == doc_);
        assertTrue(element_.getOwnerDocument() == doc_);
    }

    public void testNodeGetPreviousSibling() {
        assertTrue(element2_.getPreviousSibling() == element_);
        assertTrue(element_.getPreviousSibling() == text_);
        assertTrue(text_.getPreviousSibling() == null);
        assertTrue(root_.getPreviousSibling() == null);
        assertTrue(doc_.getPreviousSibling() == null);
    }

    public void testRemoveFromLinkedList() throws IOException, DOMException {

        assertEquals(expectedRootXml_, root_.toXml());

        root_.removeChild(element_);

        assertEquals(
            "<Root>some text<Element2 a=\"p\"/></Root>",
            root_.toXml());

        assertTrue(element2_.getPreviousSibling() == text_);
        assertTrue(text_.getPreviousSibling() == null);

        assertTrue(element2_.getNextSibling() == null);
        assertTrue(text_.getNextSibling() == element2_);
    }

    public void testEncoding() throws IOException, DOMException {
        Document doc = new Document();
        Element x = new Element("X");
        doc.setDocumentElement(x);
        Text text = new Text("\"\u0100 2<3 & 5>4\"");
        x.appendChild(text);
        assertEquals(
            "<X>&quot;&#256; 2&lt;3 &amp; 5&gt;4&quot;</X>",
            x.toXml());
    }

    public void testElementAsString()
        throws ParseException, IOException, XPathException {
        String xml = "<A>1<B>2<C>3</C>4<C/>5</B>6<B>7</B>8</A>";
        Document doc =
            Parser.parse(testUrl_, new CharArrayReader(xml.toCharArray()));

        assertEquals("12345678", doc.xpathSelectElement("/A").toString());
        assertEquals("2345", doc.xpathSelectElement("/A/B").toString());
        assertEquals("3", doc.xpathSelectElement("/A/B/C").toString());
    }

    public void testWrongXPathType() throws IOException {

        try {
            doc_.xpathSelectElement("/Root/Element2/@a");
            fail("exception not thrown as expected");
        } catch (ParseException e) {
            //as expected
        }

        try {
            doc_.xpathSelectString("/Root/Element2");
            fail("exception not thrown as expected");
        } catch (ParseException e) {
            //as expected
        }

        try {
            root_.xpathSelectElement("Element2/@a");
            fail("exception not thrown as expected");
        } catch (ParseException e) {
            //as expected
        }

        try {
            root_.xpathSelectString("Element2");
            fail("exception not thrown as expected");
        } catch (ParseException e) {
            //as expected
        }

    }

    public void testDocumentXpathSelectStrings()
        throws IOException, ParseException {
        Enumeration i = doc_.xpathSelectStrings("/Root/*/@a");

        assertTrue(i.hasMoreElements());
        assertEquals("q", i.nextElement());

        assertTrue(i.hasMoreElements());
        assertEquals("p", i.nextElement());
    }

    public void testElementXpathSelectStrings()
        throws IOException, ParseException {
        Enumeration i = root_.xpathSelectStrings("*/@a");

        assertTrue(i.hasMoreElements());
        assertEquals("q", i.nextElement());

        assertTrue(i.hasMoreElements());
        assertEquals("p", i.nextElement());
    }

    public void testDocumentToXml() throws IOException {
        assertEquals(
            "<?xml version=\"1.0\" ?>\n" + expectedRootXml_,
            doc_.toXml());
    }

    /*public void testBadDocumentClone(){
    
      try{
      //doc_.cloneNode( new Document() );
      doc_.clone();
      fail("exception not thrown as expected");
      }catch(DOMException e){
      //as expected
      assertEquals( DOMException.HIERARCHY_REQUEST_ERR, e.code );
      }
    
    
      }*/

    public void testDocumentEqualsBad() {
        assertTrue(!doc_.equals("some non-Document object"));
    }

    public void testElementEqualsDifferentChildren() throws DOMException {

        //Element clone = element_.cloneElement(true,doc_);
        Element clone = (Element) element_.clone();
        assertTrue(clone.equals(element_));

        Element cloneChild = new Element("CloneChild");
        clone.appendChild(cloneChild);
        assertTrue(!clone.equals(element_));
    }

    public void testElementEqualsDifferentAttributeCounts() {

        //Element clone = element_.cloneElement(true,doc_);
        Element clone = (Element) element_.clone();
        assertTrue(clone.equals(element_));

        clone.setAttribute("c", "r");
        assertTrue(!clone.equals(element_));
    }

    public void testElementEqualsDifferentAttributeValues() {

        //Element clone = element_.cloneElement(true,doc_);
        Element clone = (Element) element_.clone();
        assertTrue(clone.equals(element_));

        clone.setAttribute("a", "q"); //set to same
        assertTrue(clone.equals(element_));

        clone.setAttribute("a", "z"); //set to different
        assertTrue(!clone.equals(element_));
    }

    public void testAppendSameChildTwice() throws IOException, DOMException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
        root_.appendChild(element_);
        assertEquals(
            "<Root>some text<Element2 a=\"p\"/><Element a=\"q\"/></Root>",
            root_.toXml());
    }

    public void testAppendAlreadyLinkedHereElement1() throws IOException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
        Text alreadyLinked = (Text) root_.getFirstChild();
        root_.appendChild(alreadyLinked);
        assertEquals(
            "<Root><Element a=\"q\"/><Element2 a=\"p\"/>some text</Root>",
            root_.toXml());

    }
    public void testAppendAlreadyLinkedHereElement2()
        throws IOException, ParseException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
        Element alreadyLinked = root_.xpathSelectElement("Element");
        root_.appendChild(alreadyLinked);
        assertEquals(
            "<Root>some text<Element2 a=\"p\"/><Element a=\"q\"/></Root>",
            root_.toXml());

    }

    public void testAppendAlreadyLinkedElement1() throws IOException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
        Element copy = (Element) root_.clone();
        Text alreadyLinked = (Text) copy.getFirstChild();
        root_.appendChild(alreadyLinked);
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/>some text</Root>",
            root_.toXml());

    }
    public void testAppendAlreadyLinkedElement2()
        throws IOException, ParseException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
        Element copy = (Element) root_.clone();
        Element alreadyLinked = copy.xpathSelectElement("Element");
        root_.appendChild(alreadyLinked);
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/><Element a=\"q\"/></Root>",
            root_.toXml());

    }

    public void testAppendToSelf() throws IOException {
        //try{
        root_.appendChild(root_);
        root_.toXml();
        //    fail("exception not thrown as expected");
        //}catch(DOMException e){
        //    //as expected
        //    assertEquals( DOMException.HIERARCHY_REQUEST_ERR, e.code );
        //}

    }

    public void testRemoveFirstChild() throws IOException, DOMException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
        root_.removeChild(root_.getFirstChild());
        assertEquals(
            "<Root><Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
    }

    public void testRemoveFirstChildCloned() throws IOException, DOMException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
        root_.removeChild((Node) root_.getFirstChild().clone());
        assertEquals(
            "<Root><Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
    }

    public void testRemoveLastChild() throws IOException, DOMException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
        root_.removeChild(element2_);
        assertEquals("<Root>some text<Element a=\"q\"/></Root>", root_.toXml());
    }

    public void testRemoveLastChildCloned() throws IOException, DOMException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());
        root_.removeChild((Node) element2_.clone());
        assertEquals("<Root>some text<Element a=\"q\"/></Root>", root_.toXml());
    }

    public void testRemoveNonExistantChild() {
        try {
            root_.removeChild(new Element("NotInRoot"));
            fail("exception not thrown as expected");
        } catch (DOMException e) {
            //as expected
            assertEquals(DOMException.NOT_FOUND_ERR, e.code);
        }
    }

    public void testReplaceChild() throws IOException, DOMException {
        assertEquals(
            "<Root>some text<Element a=\"q\"/><Element2 a=\"p\"/></Root>",
            root_.toXml());

        root_.replaceChild(new Text("replace2"), element2_);
        assertEquals(
            "<Root>some text<Element a=\"q\"/>replace2</Root>",
            root_.toXml());

        root_.replaceChild(new Element("Replace"), element_);
        assertEquals("<Root>some text<Replace/>replace2</Root>", root_.toXml());

        root_.replaceChild(new Element("ReplaceT"), root_.getFirstChild());
        assertEquals(
            "<Root><ReplaceT/><Replace/>replace2</Root>",
            root_.toXml());

    }

    public void testReplaceNonExistantChild() {
        try {
            root_.replaceChild(
                new Element("Replace"),
                new Element("NotInRoot"));
            fail("exception not thrown as expected");
        } catch (DOMException e) {
            //as expected
            assertEquals(DOMException.NOT_FOUND_ERR, e.code);
        }
    }

    public void testParser1()
        throws MalformedURLException, ParseException, IOException {
        Reader reader1 = new CharArrayReader(expectedRootXml_.toCharArray());
        Document doc1 = Parser.parse(testUrl_, reader1);
        assertEquals(doc_, doc1);

        assertEquals(testUrl_, doc1.toString());
        assertEquals("MEMORY", doc_.toString());
    }

    public void testParser2()
        throws MalformedURLException, ParseException, IOException {
        Reader reader2 = new CharArrayReader(expectedRootXml_.toCharArray());
        Document doc2 = Parser.parse(testUrl_, reader2, log_);
        assertEquals("", log_.toString());
        assertEquals(doc_, doc2);

    }

    public void testParser3()
        throws MalformedURLException, ParseException, IOException {

        File file = new File("temp" + Math.random() + ".xml");
        Writer fileOut = new FileWriter(file);
        fileOut.write(expectedRootXml_);
        fileOut.close();
        Document doc3 =
            Parser.parse(file.toURL().toString(), new FileReader(file));
        file.delete();
        assertEquals(doc_, doc3);

    }

    public void testParser4()
        throws MalformedURLException, ParseException, IOException {
        InputStream is = new ByteArrayInputStream(expectedRootXml_.getBytes());
        Document doc4 = Parser.parse(testUrl_, is, log_);
        assertEquals(doc_, doc4);
    }

    public void testParser5()
        throws MalformedURLException, ParseException, IOException {
        InputStream is = new ByteArrayInputStream(expectedRootXml_.getBytes());
        Document doc5 = Parser.parse(testUrl_, is, log_, "UTF8");
        assertEquals(doc_, doc5);
    }

    public void testParserBadIncomplete()
        throws MalformedURLException, ParseException, IOException {
        Reader incomplete = new CharArrayReader("<Foo x='".toCharArray());
        try {
            Parser.parse(testUrl_, incomplete, log_);
            fail("exception not thrown as expected");
        } catch (ParseException e) {
            //as expected
        }
        assertEquals("error(unexpected end of expression.) ", log_.toString());
    }

    /*public void testParserBadExtraStuffAtEnd()
      throws MalformedURLException, ParseException, IOException
      {
      Reader extraStuffAtEnd = new StringReader(expectedRootXml_+"XXX");
      try{
      Parser.parse( testUrl_, extraStuffAtEnd );
      fail("exception not thrown as expected");
      }catch(ParseException e){
      //as expected
      }
      assertEquals( "error(expecting comment or processing instruction or space) ",
      log_.toString() );
      }*/

    public void testParseEntity()
        throws XPathException, ParseException, IOException {
        String xml = "<!DOCTYPE A[<!ENTITY b \"ccc\"> ]><A d='&b;'/>";
        Reader reader = new CharArrayReader(xml.toCharArray());
        Document doc = Parser.parse(testUrl_, reader);
        assertEquals("ccc", doc.xpathSelectString("/A/@d"));

    }

    public void testParserBadMarkupDecl()
        throws MalformedURLException, ParseException, IOException {
        String xml = "<!DOCTYPE A[XXXX]><A/>";
        Reader badMarkupDecl = new CharArrayReader(xml.toCharArray());
        try {
            Parser.parse(testUrl_, badMarkupDecl, log_);
            fail("exception not thrown as expected");
        } catch (ParseException e) {
            //as expected
        }
        assertEquals(
            "error(expecting processing instruction, comment, or \"<!\") ",
            log_.toString());
    }

    public void testParserBadPe()
        throws XPathException, ParseException, IOException {

        String xml = "<!DOCTYPE A[<!ENTITY b \"C%y;C\"> ]><A d='&b;' e='E'/>";
        Reader reader2 = new CharArrayReader(xml.toCharArray());
        Document doc = Parser.parse(testUrl_, reader2, log_);
        assertNotNull(doc.xpathSelectElement("/A"));
        assertEquals("A", doc.xpathSelectElement("/A").getTagName());
        assertEquals("E", doc.xpathSelectString("/A/@e"));
        assertEquals("CC", doc.xpathSelectString("/A/@d"));
        assertEquals("warning(No declaration of %y;) ", log_.toString());

    }

    public void testParserInvalidEntityValue1()
        throws MalformedURLException, ParseException, IOException {
        String xml = "<!DOCTYPE A[<!ENTITY b invalid> ]><A d='&b;'/>";
        Reader invalidEntityValue = new CharArrayReader(xml.toCharArray());
        try {
            Parser.parse(testUrl_, invalidEntityValue, log_);
            fail("exception not thrown as expected");
        } catch (ParseException e) {
            //as expected
        }
        assertEquals(
            "error(expecting double-quote, \"PUBLIC\" or \"SYSTEM\" while reading entity declaration) ",
            log_.toString());
    }

    public void testParserInvalidEntityValue2()
        throws MalformedURLException, ParseException, IOException {
        String xml = "<!DOCTYPE A[<!ENTITY b invalid>] ><A d='&b;'/>";
        Reader invalidEntityValue = new CharArrayReader(xml.toCharArray());
        try {
            Parser.parse(testUrl_, invalidEntityValue, log_);
            fail("exception not thrown as expected");
        } catch (ParseException e) {
            //as expected
        }
        assertEquals(
            "error(expecting double-quote, \"PUBLIC\" or \"SYSTEM\" while reading entity declaration) ",
            log_.toString());
    }

    public void testParserBadUnexpectesEndOfExpression()
        throws MalformedURLException, ParseException, IOException {
        String xml = "<A b=";
        Reader reader = new CharArrayReader(xml.toCharArray());
        try {
            Parser.parse(testUrl_, reader, log_);
            fail();
        } catch (ParseException e) {
            //as expected
        }
        assertEquals("error(unexpected end of expression.) ", log_.toString());
    }

    public void testParserBadUnexpectesEndOfSymbol()
        throws MalformedURLException, ParseException, IOException {
        String xml = "<?xml versi";
        Reader endOfSymbol = new CharArrayReader(xml.toCharArray());
        try {
            Parser.parse(testUrl_, endOfSymbol, log_);
            fail("exception not thrown as expected");
        } catch (ParseException e) {
            //as expected
        }
        assertEquals(
            "error(got \"end of XML file\" instead of \"version\" as expected) ",
            log_.toString());
    }

    public void testSpaceInTag()
        throws XPathException, ParseException, IOException {

        Reader reader1 = new CharArrayReader("<A/>".toCharArray());
        Element a1 = Parser.parse(testUrl_, reader1).getDocumentElement();

        Reader reader2 = new CharArrayReader("<A />".toCharArray());
        Element a2 = Parser.parse(testUrl_, reader2).getDocumentElement();

        assertEquals(a1, a2);
    }

    public void testUnderscores()
        throws ParseException, IOException, XPathException {
        String xml = "<X><A_A a_a='aaa'/><_BB _bb='bbb'/></X>";
        Document doc =
            Parser.parse(testUrl_, new CharArrayReader(xml.toCharArray()));

        assertEquals("aaa", doc.xpathSelectString("/X/A_A/@a_a") );
        assertEquals("bbb", doc.xpathSelectString("/X/_BB/@_bb"));
    }
    public void testSpaceInTag2()
        throws XPathException, ParseException, IOException {

        Element a1 = Parser.parse("<A/>".getBytes()).getDocumentElement();
        Element a2 = Parser.parse("<A />".getBytes()).getDocumentElement();

        assertEquals(a1, a2);
    }

    public void testInfiniteRecursion() throws DOMException, IOException {
        final Document doc = new Document();
        Element root = new Element("Root");
        doc.setDocumentElement(root);
        Element child = new Element("Child");

        root.appendChild(child);
        child.appendChild(root);

        Writer writer = new Writer() {
            public void close() {
            }
            public void flush() {
            }
            public void write(char[] buf, int offset, int len) {
                count_ += len;
                if (count_ > 1000)
                    throw new Error("Stuck in infinite recursion");
            }
            private int count_ = 0;
        };

        doc.toXml(writer);
    }

    private Document doc_;
    private Element root_, element_, element2_;
    private Text text_;
    private String expectedRootXml_;
    private String testUrl_;
    //Actually, just a name not a URL (field name is historical)
    private CountLog log_;

}

class CountLog implements ParseLog {
    public void error(String msg, String systemId, int lineNum) {
        msgs_.append("error(" + msg + ") ");
    }
    public void warning(String msg, String systemId, int lineNum) {
        msgs_.append("warning(" + msg + ") ");
    }
    public void note(String msg, String systemId, int lineNum) {
        msgs_.append("note(" + msg + ") ");
    }
    public String toString() {
        return msgs_.toString();
    }
    private StringBuffer msgs_ = new StringBuffer();
}

// $Log: SpartaTestCase.java,v $
// Revision 1.9  2002/10/30 23:18:43  eob
// Fixed bug [ 627024 ] doc.xpathEnsure("/top") throws exception
// http://sourceforge.net/projects/sparta-xml/
//
// Revision 1.8  2002/08/20 18:24:06  eob
// Change from old sparta package names to new ones, following the
// release to SourceForge.
//
// Revision 1.7  2002/08/18 04:54:54  eob
// Sparta no longer throws XPathException -- it throws ParseException
// instead.
//
// Revision 1.6  2002/08/15 22:52:42  eob
// Sparta node constructors no longer needs document
//
// Revision 1.5  2002/08/15 05:09:49  eob
// Add indexing tests.
//
// Revision 1.4  2002/08/05 20:04:32  sermarti
//
// Revision 1.3  2002/06/21 00:29:33  eob
// Make work with old JDK 1.1.* -- Change UTF-8 to UTF8
//
// Revision 1.2  2002/06/14 19:45:29  eob
// Add test of element toString().
//
// Revision 1.1  2002/05/23 20:28:05  eob
// initial
