package com.hp.hpl.sparta.test;

import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;

import junit.framework.TestCase;

import com.hp.hpl.sparta.*;
import com.hp.hpl.sparta.xpath.*;

/**
 *  Unit test of xpath
   <blockquote><small> Copyright (C) 2002 Hewlett-Packard Company.
   This file is part of Sparta, an XML Parser, DOM, and XPath library.
   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 2.1 of
   the License, or (at your option) any later version.  This library
   is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE. </small></blockquote>
   @version  $Date: 2002/10/30 23:18:43 $  $Revision: 1.9 $
   @author Eamonn O'Brien-Strain
 */

public class PlainXPathTestCase extends TestCase {
    public PlainXPathTestCase(String name) {
        super(name);
    }

    public void setUp() throws XPathException, IOException {
        xpath_ = XPath.get("/doc/chapter/section[@name='Section 1.1']/para");
    }

    public void testXpath() {
        assertTrue(xpath_.isAbsolute());
        assertTrue(!xpath_.isStringValue());
    }

    public void testAsXml() throws XPathException, IOException {
        String expected =
            "<XPath absolute=\"true\" stringValue=\"false\">"
                + "<Step multiLevel=\"false\" stringValue=\"false\">"
                + "<ElementTest tagName=\"doc\"/>"
                + "<TrueExpr/>"
                + "</Step>"
                + "<Step multiLevel=\"false\" stringValue=\"false\">"
                + "<ElementTest tagName=\"chapter\"/>"
                + "<TrueExpr/>"
                + "</Step>"
                + "<Step multiLevel=\"false\" stringValue=\"false\">"
                + "<ElementTest tagName=\"section\"/>"
                + "<AttrEqualsExpr attrName=\"name\" attrValue=\"Section 1.1\"/>"
                + "</Step>"
                + "<Step multiLevel=\"false\" stringValue=\"false\">"
                + "<ElementTest tagName=\"para\"/>"
                + "<TrueExpr/>"
                + "</Step>"
                + "</XPath>";

        XmlVisitor visitor = new XmlVisitor(xpath_);
        assertEquals(
            expected,
            visitor.getDocument().getDocumentElement().toXml());
    }

    public void testStep() throws XPathException {
        int stepCount = 0;
        for (Enumeration i = xpath_.getSteps(); i.hasMoreElements();) {
            Step a = (Step) i.nextElement();
            assertTrue(!a.isMultiLevel());
            assertTrue(!a.isStringValue());
            ++stepCount;
        }
        assertEquals(4, stepCount);

    }

    void incrementPredicateCount(){
        ++predicateCount_;
    }

    public void testPredicate() throws XPathException {

        predicateCount_ = 0;
        Visitor visitor = new BaseVisitor() {
            public void visit(AttrEqualsExpr a) throws XPathException {
                incrementPredicateCount();
                assertEquals("name", a.getAttrName());
                assertEquals("Section 1.1", a.getAttrValue());
            }
        };

        for (Enumeration i = xpath_.getSteps(); i.hasMoreElements();) {
            Step a = (Step) i.nextElement();
            a.getPredicate().accept(visitor);
        }
        assertEquals(1, predicateCount_);

    }
    private int predicateCount_;

    public void testStringVersusElement() throws IOException, XPathException {
        assertTrue(!XPath.isStringValue("para"));
        assertTrue(!XPath.isStringValue("*"));
        assertTrue(XPath.isStringValue("@name"));
        assertTrue(!XPath.isStringValue("*/para"));
        assertTrue(!XPath.isStringValue("chapter//para"));
        assertTrue(!XPath.isStringValue("chapter//para"));
        assertTrue(!XPath.isStringValue("//olist/item"));
        assertTrue(!XPath.isStringValue("."));
        assertTrue(!XPath.isStringValue(".//para"));
        assertTrue(!XPath.isStringValue(".."));
        assertTrue(XPath.isStringValue("../@lang"));
        assertTrue(!XPath.isStringValue("para[@type=\"warning\"]"));
        assertTrue(!XPath.isStringValue("para[@type!=\"warning\"]"));
        assertTrue(!XPath.isStringValue("para[@type]"));
        assertTrue(
            !XPath.isStringValue("/doc/chapter/section[@name='Section 1.2']"));
        assertTrue(!XPath.isStringValue("doc/chapter"));
        assertTrue(
            !XPath.isStringValue("doc/chapter/section[@name='Section 1.2']"));
        assertTrue(!XPath.isStringValue("/MetaData/Child[@name='public']"));
        assertTrue(!XPath.isStringValue("*[@expires-offset]"));
        assertTrue(!XPath.isStringValue("../*"));
    }

    public void testXPathBigParse() throws XPathException {
        XPath parseTree =
            XPath.get("/a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/t/u/v/w/x/y/z");
        Enumeration e = parseTree.getSteps();
        int count = 0;
        while (e.hasMoreElements()) {
            e.nextElement();
            ++count;
        }
        assertEquals(26, count);

    }

    public void testManyXPathSelect() throws ParseException, IOException {
        Document doc = Parser.parse("build.xml", new FileReader("build.xml"));
        recurseXPathSelect(doc, "", doc.getDocumentElement());
    }

    private void recurseXPathSelect(
        Document doc,
        String parentSelect,
        Element e)
        throws ParseException {
        String elementSelect = parentSelect + "/" + e.getTagName();
        checkContains(doc.xpathSelectElements(elementSelect), e);
        for (Node n = e.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element)
                recurseXPathSelect(doc, elementSelect, (Element) n);
            else
                recurseXPathSelect(doc, elementSelect, (Text) n);
        }
        for (Enumeration i = e.getAttributeNames(); i.hasMoreElements();) {
            String name = (String) i.nextElement();
            String value = e.getAttribute(name);
            String xpath = elementSelect + "/@" + name;
            checkContains(doc.xpathSelectStrings(xpath), value);
            xpath = elementSelect + "[@" + name + "]";
            checkContains(doc.xpathSelectElements(xpath), e);
            xpath = elementSelect + "[@" + name + "=\"" + value + "\"]";
            checkContains(doc.xpathSelectElements(xpath), e);
        }
    }

    public void testUnderScore() throws IOException, ParseException {
        Document doc1 = Parser.parse("<a><b qqq='w'/></a>".getBytes());
        Document doc2 = Parser.parse("<a><b q_q='w'/></a>".getBytes());
        assertEquals("b", doc1.xpathSelectElement("/a/b[@qqq]").getTagName());
        assertEquals("b", doc2.xpathSelectElement("/a/b[@q_q]").getTagName());
    }

    public void testUnterminatedQuote() {
        String bad = "a\"b";
        try {
            XPath.get(bad);
            fail();
        } catch (XPathException e) {
            // as expected
        }
    }

    public void testPosn() throws IOException, ParseException {
        String x =
            "<messages><chat message=\"**System: John has entered the room!\n"
                + "\"/><chat message=\"John: howdyt\n"
                + "\"/><chat message=\"John: cool\n"
                + "\"/><chat message=\"**System: John has left the room!\n"
                + "\"/><chat message=\"**System: John has entered the room!\n"
                + "\"/><chat message=\"John: teste\n"
                + "\"/></messages>";
        Element e = Parser.parse(x).getDocumentElement();
        Element chat = e.xpathSelectElement("chat");
        assertNotNull(chat);
        Element first = e.xpathSelectElement("chat[1]");
        assertNotNull(first);
        assertEquals(
            "**System: John has entered the room!\n",
            first.getAttribute("message"));
    }

    private void checkContains(Enumeration i, Element node) {
        assertTrue(i.hasMoreElements());
        do {
            Element n = (Element) i.nextElement();
            if (n == node)
                return; //found it
        } while (i.hasMoreElements());
        fail(); //did not find it
    }

    private void recurseXPathSelect(
        Document doc,
        String parentSelect,
        Text text)
        throws ParseException {
        String textSelect = parentSelect + "/text()";
        checkContains(doc.xpathSelectStrings(textSelect), text);
    }

    private void checkContains(Enumeration i, Text node) {
        assertTrue(i.hasMoreElements());
        do {
            String n = (String) i.nextElement();
            if (n.equals(node.getData()))
                return; //found it
        } while (i.hasMoreElements());
        fail(); //did not find it
    }

    private void checkContains(Enumeration i, String value) {
        assertTrue(i.hasMoreElements());
        do {
            String s = (String) i.nextElement();
            if (s.equals(value))
                return; //found it
        } while (i.hasMoreElements());
        fail(); //did not find it
    }

    private XPath xpath_;
}

/** all methods do nothing */
class BaseVisitor implements Visitor {

    public void visit(AllElementTest a) {
    }
    public void visit(ThisNodeTest a) {
    }
    public void visit(ParentNodeTest a) throws XPathException {
    }
    public void visit(ElementTest a) {
    }
    public void visit(AttrTest a) {
    }
    public void visit(TextTest a) {
    }

    public void visit(TrueExpr a) {
    }
    public void visit(AttrExistsExpr a) throws XPathException {
    }
    public void visit(AttrEqualsExpr a) throws XPathException {
    }
    public void visit(AttrLessExpr a) throws XPathException {
    }
    public void visit(AttrGreaterExpr a) throws XPathException {
    }
    public void visit(AttrNotEqualsExpr a) throws XPathException {
    }
    public void visit(TextExistsExpr a) throws XPathException {
    }
    public void visit(TextEqualsExpr a) throws XPathException {
    }
    public void visit(TextNotEqualsExpr a) throws XPathException {
    }
    public void visit(PositionEqualsExpr a) throws XPathException {
    }
}

class XmlVisitor extends BaseVisitor {

    XmlVisitor(XPath xpath) throws XPathException {

        Element xpathE = new Element("XPath");
        xpathE.setAttribute("absolute", xpath.isAbsolute() + "");
        xpathE.setAttribute("stringValue", xpath.isStringValue() + "");
        doc_.setDocumentElement(xpathE);
        for (Enumeration i = xpath.getSteps(); i.hasMoreElements();) {
            Step step = (Step) i.nextElement();
            Element stepE = new Element("Step");
            stepE.setAttribute("multiLevel", step.isMultiLevel() + "");
            stepE.setAttribute("stringValue", step.isStringValue() + "");
            doc_.getDocumentElement().appendChild(stepE);
            step.getNodeTest().accept(this);
            step.getPredicate().accept(this);
        }

    }

    private Document doc_ = new Document();

    Document getDocument() {
        return doc_;
    }

    private void appendToStep(String eName) {
        Element e = new Element(eName);
        Element step = (Element) doc_.getDocumentElement().getLastChild();
        step.appendChild(e);
    }

    private void setAttribute(String name, String value) {
        Element step = (Element) doc_.getDocumentElement().getLastChild();
        Element element = (Element) step.getLastChild();
        element.setAttribute(name, value);
    }

    public void visit(AllElementTest a) {
        appendToStep("AllElementTest");
    }
    public void visit(ThisNodeTest a) {
        appendToStep("ThisNodeTest");
    }
    public void visit(ParentNodeTest a) throws XPathException {
        appendToStep("ParentNodeTest");
    }
    public void visit(ElementTest a) {
        appendToStep("ElementTest");
        setAttribute("tagName", a.getTagName() + "");
    }
    public void visit(AttrTest a) {
        appendToStep("AttrTest");
        setAttribute("attrName", a.getAttrName());
    }

    public void visit(TrueExpr a) {
        appendToStep("TrueExpr");
    }
    public void visit(AttrExistsExpr a) throws XPathException {
        appendToStep("AttrExistsExpr");
        setAttribute("attrName", a.getAttrName());
    }
    public void visit(AttrEqualsExpr a) throws XPathException {
        appendToStep("AttrEqualsExpr");
        setAttribute("attrName", a.getAttrName());
        setAttribute("attrValue", a.getAttrValue());
    }
    public void visit(AttrNotEqualsExpr a) throws XPathException {
        appendToStep("AttrNotEqualsExpr");
        setAttribute("attrName", a.getAttrName());
        setAttribute("attrValue", a.getAttrValue());
    }
}

// $Log: PlainXPathTestCase.java,v $
// Revision 1.8  2002/12/05 07:02:26  eob
// Add less than and greater than in XPath predicates.
//
// Revision 1.7  2002/10/30 23:19:56  eob
// Feature request [ 630127 ] Support /a/b[text()='foo']
// http://sourceforge.net/projects/sparta-xml/
//
// Revision 1.6  2002/09/19 20:59:00  eob
// Add support for position attribute in XPath.
//
// Revision 1.5  2002/08/20 18:47:17  eob
// Use new sparta package names after release to SourceForge.
//
// Revision 1.4  2002/08/15 22:53:28  eob
// Sparta node constructors no longer needs document
//
// Revision 1.3  2002/06/14 19:42:35  eob
// Add handling of "text()" in XPath expressions.
//
// Revision 1.2  2002/06/04 05:32:50  eob
// Add some more tests.
//
// Revision 1.1  2002/05/10 19:49:33  eob
// initial
