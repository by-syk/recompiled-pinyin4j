package com.hp.hpl.sparta.test;

import java.io.CharArrayReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Enumeration;

import junit.swingui.TestRunner;

import com.hp.hpl.sparta.*;

/**
 * Unit test case of SpartaXPath

   <blockquote><small> Copyright (C) 2002 Hewlett-Packard Company.
   This file is part of Sparta, an XML Parser, DOM, and XPath library.
   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 2.1 of
   the License, or (at your option) any later version.  This library
   is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE. </small></blockquote>
   @version  $Date: 2002/10/30 23:18:43 $  $Revision: 1.9 $
   @author Eamonn O'Brien-Strain
 */

public class SpartaXPathTestCase extends XPathTestCase {

    public SpartaXPathTestCase(String name) {
        super(name);
    }

    public void setUp()
        throws
            MalformedURLException,
            ParseException,
            IOException,
            NoSuchElementException {
        for (int i = 0; i < XML.length; ++i) {
            doc_[i] = parse(XML[i]);
        }
        abXml_ =
            "<a>" + "  <b x=\"ppp\"/>" + "  <b y=\"qqq\"/>" + "  <b/>" + "</a>";
        abDoc_ = parse(abXml_);

        chapter_1_ = firstChildElement(doc_[0].getDocumentElement());
        section_1_1_ = firstChildElement(chapter_1_);
        section_1_2_ = nextSiblingElement(section_1_1_);
    }

    static private Element firstChildElement(Element parent)
        throws NoSuchElementException {
        for (Node n = parent.getFirstChild();
            n != null;
            n = n.getNextSibling())
            if (n instanceof Element)
                return (Element) n;
        throw new NoSuchElementException();
    }

    static private Element nextSiblingElement(Element prev)
        throws NoSuchElementException {
        for (Node n = prev.getNextSibling(); n != null; n = n.getNextSibling())
            if (n instanceof Element)
                return (Element) n;
        throw new NoSuchElementException();
    }

    public void testPara()
        throws IOException, NoSuchElementException, ParseException {

        Enumeration nodes = section_1_1_.xpathSelectElements("para");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testStar()
        throws ParseException, IOException, NoSuchElementException {

        Enumeration nodes = section_1_1_.xpathSelectElements("*");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testTextSingle()
        throws IOException, NoSuchElementException, ParseException {
        Element para111 =
            section_1_1_.xpathSelectElement("para[@type='error']");
        String text111 = para111.xpathSelectString("text()");
        assertEquals(PARA_1_1_1, text111);
    }

    public void testIndex()
        throws IOException, NoSuchElementException, ParseException {
        Element relative =
            section_1_1_.xpathSelectElement("para[@type='error']");

        String xp =
            "/doc/chapter[@name='Chapter 1']/section[@name='Section 1.1']/para";
        Element fromDoc = doc_[0].xpathSelectElement(xp + "[@type='error']");
        assertEquals(relative, fromDoc);

        Document.Index index = doc_[0].xpathGetIndex(xp + "[@type]");
        //assertEquals(2, index.size());
        assertEquals(fromDoc, index.get("error").nextElement());
        assertTrue(index.get("error").hasMoreElements());
        assertTrue(index.get("warning").hasMoreElements());
        assertTrue(!index.get("bogus").hasMoreElements());

    }

    public void testXpathHasIndex()
        throws IOException, NoSuchElementException, ParseException {
        String xp =
            "/doc/chapter[@name='Chapter 1']/section[@name='Section 1.1']/para[@type]";

        assertTrue(!doc_[0].xpathHasIndex(xp));
        assertTrue(!doc_[0].xpathHasIndex("bogus"));

        /*Document.Index index =*/
        doc_[0].xpathGetIndex(xp);

        assertTrue(doc_[0].xpathHasIndex(xp));
        assertTrue(!doc_[0].xpathHasIndex("bogus"));
    }

    public void testIndexInvalidate()
        throws IOException, NoSuchElementException, ParseException {
        String xp =
            "/doc/chapter[@name='Chapter 1']/section[@name='Section 1.1']/para";
        Document.Index index = doc_[0].xpathGetIndex(xp + "[@type]");
        //assertEquals(2, index.size());
        assertTrue(index.get("error").hasMoreElements());
        assertTrue(index.get("warning").hasMoreElements());
        assertTrue(!index.get("bogus").hasMoreElements());

        Element para = doc_[0].xpathSelectElement(xp + "[@type='error']");
        para.removeAttribute("type");
        para = doc_[0].xpathSelectElement(xp + "[@type='error']");
        ;
        assertNull(para);

        //assertEquals(1, index.size());
        assertTrue(!index.get("error").hasMoreElements());
        assertTrue(index.get("warning").hasMoreElements());
        assertTrue(!index.get("bogus").hasMoreElements());
    }

    public void testTextSplit()
        throws IOException, NoSuchElementException, ParseException {
        Element para121 = section_1_2_.xpathSelectElement("para");
        String text121 = para121.xpathSelectString("text()");
        assertEquals(PARA_1_2_1a, text121);

        Enumeration nodes = para121.xpathSelectStrings("text()");

        assertEquals(PARA_1_2_1a, nodes.nextElement());
        assertEquals(PARA_1_2_1b, nodes.nextElement());
        assertTrue(!nodes.hasMoreElements());

    }

    public void testAttr()
        throws IOException, NoSuchElementException, ParseException {
        String value = section_1_1_.xpathSelectString("@name");
        assertEquals("Section 1.1", value);
    }

    public void testParaPosn1()
        throws IOException, NoSuchElementException, ParseException {
        Element para = section_1_1_.xpathSelectElement("para[1]");
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());
    }

    public void testStarPara()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = chapter_1_.xpathSelectElements("*/para");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testChapter5Section2()
        throws IOException, NoSuchElementException, ParseException {
        Element element =
            doc_[0].xpathSelectElement("/doc/chapter[5]/section[2]");

        assertEquals("Section 5.2", element.getAttribute("name"));
    }

    public void testChapterPara()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            doc_[0].getDocumentElement().xpathSelectElements("chapter//para");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testAllPara()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            doc_[0].getDocumentElement().xpathSelectElements("chapter//para");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testAllOlistPara()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = doc_[0].xpathSelectElements("//olist/item");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        assertNotNull(para);
        Text text = (Text) para.getFirstChild();
        assertEquals(ITEM_1_2_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(ITEM_1_2_2, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testDot()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = section_1_1_.xpathSelectElements(".");

        assertTrue(nodes.hasMoreElements());
        Element element = (Element) nodes.nextElement();
        assertTrue(element == section_1_1_);

        assertTrue(!nodes.hasMoreElements());
    }

    public void testDescendentPara()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = chapter_1_.xpathSelectElements(".//para");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testDotDot()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = section_1_1_.xpathSelectElements("..");

        assertTrue(nodes.hasMoreElements());
        Element element = (Element) nodes.nextElement();
        assertTrue(element == chapter_1_);

        assertTrue(!nodes.hasMoreElements());
    }

    public void testDotDotSlashAttrLang()
        throws IOException, NoSuchElementException, ParseException {
        String lang = chapter_1_.xpathSelectString("../@lang");

        assertEquals("en", lang);
    }

    public void testParaTypeWarning()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            section_1_1_.xpathSelectElements("para[@type=\"warning\"]");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testParaTypeNotWarning()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            section_1_1_.xpathSelectElements("para[@type!=\"warning\"]");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testParaType()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = section_1_1_.xpathSelectElements("para[@type]");

        assertTrue(nodes.hasMoreElements());
        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertTrue(nodes.hasMoreElements());
        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());
    }

    public void testAbs()
        throws IOException, NoSuchElementException, ParseException {
        String xpath = "/doc/chapter/section[@name='Section 1.2']";
        Element element = doc_[0].xpathSelectElement(xpath);

        assertNotNull(element);
        assertEquals("Section 1.2", element.getAttribute("name"));

    }

    public void testDocRel()
        throws IOException, NoSuchElementException, ParseException {
        String xpath = "doc/chapter/section[@name='Section 1.2']";
        Element element = doc_[0].xpathSelectElement(xpath);

        assertNotNull(element);
        assertEquals("Section 1.2", element.getAttribute("name"));

    }

    public void testEquivalence()
        throws IOException, NoSuchElementException, ParseException {
        Element e1 =
            doc_[0].xpathSelectElement(
                "/doc/chapter/section[@name='Section 1.2']");
        Element e2 =
            doc_[0].xpathSelectElement(
                "doc/chapter/section[@name='Section 1.2']");
        Element e3 =
            doc_[0].getDocumentElement().xpathSelectElement(
                "chapter/section[@name='Section 1.2']");

        assertNotNull(e1);
        assertTrue(e1 == e2);
        assertTrue(e1 == e3);
    }

    public void testFromDoc1()
        throws IOException, NoSuchElementException, ParseException {
        Element element = doc_[0].xpathSelectElement("doc/chapter");
        assertNotNull(element);
        assertEquals("Chapter 1", element.getAttribute("name"));

    }

    public void testFromDoc2()
        throws IOException, NoSuchElementException, ParseException {
        String xpath = "doc/chapter/section[@name='Section 1.2']";
        Element element = doc_[0].xpathSelectElement(xpath);

        assertNotNull(element);
        assertEquals("Section 1.2", element.getAttribute("name"));

    }

    public void testMetadata()
        throws IOException, NoSuchElementException, ParseException {
        Element a =
            doc_[1].xpathSelectElement("/MetaData/Child[@name='public']");
        assertNotNull(a);
        Element b = a.xpathSelectElement("*[@expires-offset]");
        assertNull(b);

    }

    public void testMetadataRel()
        throws IOException, NoSuchElementException, ParseException {
        Element a =
            doc_[1].xpathSelectElement("MetaData/Child[@name='public']");
        assertNotNull(a);
        Element b = a.xpathSelectElement("*[@expires-offset]");
        assertNull(b);

    }

    public void testBadNoParent() throws IOException, NoSuchElementException {
        try {
            doc_[0].xpathSelectElement("../*");
            fail("Expected exception was not thrown.");
        } catch (ParseException e) {
            //This was expected.  Do nothing.
        }
    }

    public void testSet1doc() throws IOException, ParseException {
        String xpath = "/doc/chapter/section/olist/@id";
        assertEquals(doc_[0].xpathSelectString(xpath), "foo");
        doc_[0].xpathSetStrings(xpath, "bar");
        assertEquals(doc_[0].xpathSelectString(xpath), "bar");
    }

    public void testSet1elem() throws IOException, ParseException {
        String xpath = "section/olist/@id";
        assertEquals(chapter_1_.xpathSelectString(xpath), "foo");
        chapter_1_.xpathSetStrings(xpath, "bar");
        assertEquals(chapter_1_.xpathSelectString(xpath), "bar");
    }

    public void testSet2() throws IOException, ParseException {
        abDoc_.xpathSetStrings("/a/b/@x", "rrr");
        Document expected =
            parse(
                "<a>"
                    + "  <b x='rrr'/>"
                    + "  <b x='rrr' y='qqq'/>"
                    + "  <b x='rrr'/>"
                    + "</a>");
        assertEquals(expected, abDoc_);
    }

    public void testSet4() throws IOException, ParseException {
        abDoc_.xpathSetStrings("/a/b/text()", "TTT");
        Document expected =
            parse(
                "<a>"
                    + "  <b x='ppp'>TTT</b>"
                    + "  <b y='qqq'>TTT</b>"
                    + "  <b>TTT</b>"
                    + "</a>");
        assertEquals(expected, abDoc_);
    }

    public void testSet3() throws IOException, ParseException {
        abDoc_.xpathSetStrings("/a/text()", "TTT");
        Document expected = parse("<a>TTT<b x='ppp'/><b y='qqq'/><b/></a>");
        assertEquals(expected.toXml(), abDoc_.toXml());
        assertEquals(expected, abDoc_);
    }

    public void testSetBad1() throws IOException {
        try {
            abDoc_.xpathSetStrings("/a/b", "rrr");
            fail();
        } catch (ParseException e) {
            //as expected
        }
    }

    public void testSetBad2() throws IOException {
        try {
            abDoc_.xpathSetStrings("/a/b/", "rrr");
            fail();
        } catch (ParseException e) {
            //as expected
        }
    }

    public void testSetBad3() throws IOException {
        Element root = abDoc_.getDocumentElement();

        assertEquals("before set", abXml_, root.toXml());
        try {
            abDoc_.xpathSetStrings("/a/b/@", "rrr");
            assertEquals("after set", abXml_, root.toXml());
            fail();
        } catch (ParseException e) {
            //as expected
        }
    }
    
    public void testSetChange() throws IOException, ParseException {
        String xpath = "/doc/chapter/section/olist/@id";
        assertEquals(doc_[0].xpathSelectString(xpath), "foo");
        
        assertTrue(  doc_[0].xpathSetStrings(xpath, "bar") );
        assertEquals(doc_[0].xpathSelectString(xpath), "bar");

        assertTrue( !doc_[0].xpathSetStrings(xpath, "bar") );
        assertEquals(doc_[0].xpathSelectString(xpath), "bar");
        
        assertTrue(  doc_[0].xpathSetStrings(xpath, "blah") );
        assertEquals(doc_[0].xpathSelectString(xpath), "blah");
        
        assertTrue( !doc_[0].xpathSetStrings(xpath, "blah") );
        assertEquals(doc_[0].xpathSelectString(xpath), "blah");
    }



    public void testEnsureExists() throws ParseException, IOException {
        String xpath = "/a/b[@x='ppp']";
        assertNotNull(abDoc_.xpathSelectElement(xpath));
        assertTrue(!abDoc_.xpathEnsure(xpath));
    }

    public void testEnsureNotExists() throws ParseException, IOException {
        String xpath = "/a/b[@x='XXXXXXX']";
        assertNull(abDoc_.xpathSelectElement(xpath));
        assertTrue(abDoc_.xpathEnsure(xpath));
        assertNotNull(abDoc_.xpathSelectElement(xpath));
        assertTrue(!abDoc_.xpathEnsure(xpath));
    }

    public void testEnsureNoRoot() throws ParseException, IOException {
        String xpath = "/a/b[@x='ppp']";
        Document doc = new Document();
        assertNull(doc.xpathSelectElement(xpath));
        assertTrue(doc.xpathEnsure(xpath));
        assertNotNull(doc.xpathSelectElement(xpath));
        assertEquals("<a><b x=\"ppp\"/></a>", doc.getDocumentElement().toXml());
    }

    public void testEnsureNoRoot1() throws ParseException, IOException {
        String xpath = "/a/b[@x='ppp']";
        Document doc = new Document();
        assertNull(doc.xpathSelectElement(xpath));
    }

    public void testEnsureNoRoot2() throws ParseException, IOException {
        String xpath = "/a/b[@x='ppp']";
        Document doc = new Document();
        assertTrue(doc.xpathEnsure(xpath));
    }

    public void testEnsureNoRoot3() throws ParseException, IOException {
        String xpath = "/a/b[@x='ppp']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertNotNull(doc.xpathSelectElement(xpath));
        assertEquals("<a><b x=\"ppp\"/></a>", doc.getDocumentElement().toXml());
    }

    public void testEnsureNoRoot4() throws ParseException, IOException {
        String xpath = "/a/b[@x='ppp']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a><b x=\"ppp\"/></a>", doc.getDocumentElement().toXml());
    }

    public void testEnsureMakeRootConflict() throws ParseException, IOException {
        String xpath = "/a";
        Document doc = new Document();
        doc.setDocumentElement(new Element("b"));
        try {
            doc.xpathEnsure(xpath);
            fail();
        } catch (ParseException e) {
            //as expected
        }
    }

    public void testEnsureMakeRoot() throws ParseException, IOException {
        String xpath = "/a";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a/>", doc.getDocumentElement().toXml());
    }

    public void testEnsureWithSlashInStep() throws ParseException {
        Document doc = new Document();
        String xpath = "/foo[@bar='a/b']";
        assertNull(doc.xpathSelectElement(xpath));
        assertTrue(doc.xpathEnsure(xpath));
        assertNotNull(doc.xpathSelectElement(xpath));
        assertTrue(!doc.xpathEnsure(xpath));
   }

    public void testEnsureRootPosn1() throws ParseException, IOException {
        String xpath = "/a[1]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a/>", doc.getDocumentElement().toXml());
    }
    
    public void testEnsureRootPosn2() throws ParseException, IOException {
        String xpath = "/a[2]";
        Document doc = new Document();
        try {
            doc.xpathEnsure(xpath);
            fail();
        } catch (ParseException e) {
            //as expected
        }
    }
    
    public void testEnsureRootAttrExists() throws ParseException, IOException {
        String xpath = "/a[@foo]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a foo=\"something\"/>", doc.getDocumentElement().toXml());
    }

    public void testEnsureRootAttrEquals() throws ParseException, IOException {
        String xpath = "/a[@foo='bar']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a foo=\"bar\"/>", doc.getDocumentElement().toXml());
    }


    public void testEnsureRootAttrNotEquals() throws ParseException, IOException {
        String xpath = "/a[@foo!='bar']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a foo=\"not bar\"/>", doc.getDocumentElement().toXml());
    }


    public void testEnsureRootAttrGreater() throws ParseException, IOException {
        String xpath = "/a[@foo>6]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a foo=\""+Long.MAX_VALUE+"\"/>", doc.getDocumentElement().toXml());
    }


    public void testEnsureRootAttrLess() throws ParseException, IOException {
        String xpath = "/a[@foo<6]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a foo=\""+Long.MIN_VALUE+"\"/>", doc.getDocumentElement().toXml());
    }


    public void testEnsureRootTextExists() throws ParseException, IOException {
        String xpath = "/a[text()]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a>something</a>", doc.getDocumentElement().toXml());
    }


    public void testEnsureRootTextEquals() throws ParseException, IOException {
        String xpath = "/a[text()='bar']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a>bar</a>", doc.getDocumentElement().toXml());
    }


    public void testEnsureRootTextNotEquals() throws ParseException, IOException {
        String xpath = "/a[text()!='bar']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<a>not bar</a>", doc.getDocumentElement().toXml());
    }
    
    
    public void testEnsurePosn1() throws ParseException, IOException {
        String xpath = "/p/a[1]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<p><a/></p>", doc.getDocumentElement().toXml());
    }
    
    public void testEnsurePosn2() throws ParseException, IOException {
        String xpath = "/p/a[2]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<p><a/><a/></p>", doc.getDocumentElement().toXml());
    }
    
    public void testEnsurePosn5() throws ParseException, IOException {
        String xpath = "/p/a[5]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<p><a/><a/><a/><a/><a/></p>", doc.getDocumentElement().toXml());
    }
    
    
    public void testEnsureAttrExists() throws ParseException, IOException {
        String xpath = "/p/a[@foo]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<p><a foo=\"something\"/></p>", doc.getDocumentElement().toXml());
    }

    public void testEnsureAttrEquals() throws ParseException, IOException {
        String xpath = "/p/a[@foo='bar']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<p><a foo=\"bar\"/></p>", doc.getDocumentElement().toXml());
    }


    public void testEnsureAttrNotEquals() throws ParseException, IOException {
        String xpath = "/r/a[@foo!='bar']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<r><a foo=\"not bar\"/></r>", doc.getDocumentElement().toXml());
    }


    public void testEnsureAttrGreater() throws ParseException, IOException {
        String xpath = "/r/a[@foo>6]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<r><a foo=\""+Long.MAX_VALUE+"\"/></r>", doc.getDocumentElement().toXml());
    }


    public void testEnsureAttrLess() throws ParseException, IOException {
        String xpath = "/r/a[@foo<6]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<r><a foo=\""+Long.MIN_VALUE+"\"/></r>", doc.getDocumentElement().toXml());
    }


    public void testEnsureTextExists() throws ParseException, IOException {
        String xpath = "/r/a[text()]";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<r><a>something</a></r>", doc.getDocumentElement().toXml());
    }


    public void testEnsureTextEquals() throws ParseException, IOException {
        String xpath = "/r/a[text()='bar']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<r><a>bar</a></r>", doc.getDocumentElement().toXml());
    }


    public void testEnsureTextNotEquals() throws ParseException, IOException {
        String xpath = "/r/a[text()!='bar']";
        Document doc = new Document();
        doc.xpathEnsure(xpath);
        assertEquals("<r><a>not bar</a></r>", doc.getDocumentElement().toXml());
    }
    


    public void testPredicateInMiddle()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            doc_[0].xpathSelectElements(
                "/doc/chapter/section[@name='Section 1.1']/para");

        Element para1 = (Element) nodes.nextElement();
        assertNotNull(para1);
        Text text1 = (Text) para1.getFirstChild();
        assertEquals(PARA_1_1_1, text1.getData());

        Element para2 = (Element) nodes.nextElement();
        assertNotNull(para2);
        Text text2 = (Text) para2.getFirstChild();
        assertEquals(PARA_1_1_2, text2.getData());

        assertTrue(!nodes.hasMoreElements());

    }

     
     
    public void testPara4()
        throws IOException, NoSuchElementException, ParseException {
        Element para =
            doc_[0].xpathSelectElement("/doc/chapter/section/para[4]");
        assertNull(para);
    }

    public void testPara2()
        throws IOException, NoSuchElementException, ParseException {
        Element para = section_1_1_.xpathSelectElement("para[2]");
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());
    }

    public void testPosition1()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            doc_[0].xpathSelectElements("/doc/chapter/section/para[1]");

        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        assertTrue(!nodes.hasMoreElements());

    }

    public void testPosition2()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            doc_[0].xpathSelectElements("/doc/chapter/section/para[2]");

        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());

    }

    public void testSlashSlashPara1()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = doc_[0].xpathSelectElements("//para[1]");

        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        assertTrue(!nodes.hasMoreElements());

    }

    public void testSlashSlashPara2()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = doc_[0].xpathSelectElements("//para[2]");

        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());

    }

    public void testDotPosn()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = section_1_1_.xpathSelectElements(".[1]");

        assertTrue(nodes.hasMoreElements());
        Element element = (Element) nodes.nextElement();
        assertTrue(element == section_1_1_);

        assertTrue(!nodes.hasMoreElements());
    }

    public void testDotDotPosn()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = section_1_1_.xpathSelectElements("..[1]");

        assertTrue(nodes.hasMoreElements());
        Element element = (Element) nodes.nextElement();
        assertTrue(element == chapter_1_);

        assertTrue(!nodes.hasMoreElements());
    }

    public void testStarPosn1()
        throws IOException, NoSuchElementException, ParseException {
        Element para = section_1_1_.xpathSelectElement("*[1]");
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());
    }

    public void testStarPosn4()
        throws IOException, NoSuchElementException, ParseException {
        Element para = doc_[0].xpathSelectElement("/doc/chapter/section/*[4]");
        assertNull(para);
    }

    public void testStarPosn2()
        throws IOException, NoSuchElementException, ParseException {
        Element para = section_1_1_.xpathSelectElement("*[2]");
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());
    }

    public void testStarPosition1()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            doc_[0].xpathSelectElements("/doc/chapter/section/*[1]");

        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        para = (Element) nodes.nextElement();
        assertEquals("nlist", para.getTagName());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        assertTrue(!nodes.hasMoreElements());

    }

    public void testStarPosition2()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            doc_[0].xpathSelectElements("/doc/chapter/section/*[2]");

        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextElement();
        assertEquals("olist", para.getTagName());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());

    }

    public void testSlashSlashStarPosn1()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = doc_[0].xpathSelectElements("//*[1]");

        Element element = (Element) nodes.nextElement();
        assertEquals("doc", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("chapter", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("section", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("br", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("item", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("nlist", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("item", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("section", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("section", element.getTagName());

        assertTrue(!nodes.hasMoreElements());

    }

    public void testSlashSlashStarPosn2()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes = doc_[0].xpathSelectElements("//*[2]");

        Element element = (Element) nodes.nextElement();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("section", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("olist", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("item", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("item", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("chapter", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextElement();
        assertEquals("section", element.getTagName());

        assertTrue(!nodes.hasMoreElements());

    }

    public void testText()
        throws IOException, NoSuchElementException, ParseException {
        String text111 =
            section_1_1_.xpathSelectString("para[@type='error']/text()");
        assertEquals(PARA_1_1_1, text111);
    }

    public void testTextExists()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration i = section_1_1_.xpathSelectElements("para[text()]");
        Element para = (Element) i.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) i.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(!i.hasMoreElements());
    }

    public void testTextEquals()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration i =
            section_1_1_.xpathSelectElements(
                "para[text()='" + PARA_1_1_1 + "']");
        Element para = (Element) i.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertTrue(!i.hasMoreElements());
    }

    public void testTextNotEquals()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration i =
            section_1_1_.xpathSelectElements(
                "para[text()!='" + PARA_1_1_1 + "']");
        Element para = (Element) i.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(!i.hasMoreElements());
    }

    public void testLessThan()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            doc_[0].xpathSelectElements("/doc/*/section/para[@count<6]");

        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());

    }

    public void testGreaterThan()
        throws IOException, NoSuchElementException, ParseException {
        Enumeration nodes =
            doc_[0].xpathSelectElements("/doc/*/section/para[@count>16]");

        Element para = (Element) nodes.nextElement();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        para = (Element) nodes.nextElement();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        assertTrue(!nodes.hasMoreElements());

    }

    private Document parse(String xml)
        throws MalformedURLException, ParseException, IOException {
        return Parser.parse(getName(), new CharArrayReader(xml.toCharArray()));
    }

    private final Document[] doc_ = new Document[XML.length];
    private String abXml_;
    private Document abDoc_;
    private Element chapter_1_, section_1_1_, section_1_2_;

    public static void main(String[] args) {
        TestRunner.main(
            new String[] { "-noloading", SpartaXPathTestCase.class.getName()});
    }

}

// $Log: SpartaXPathTestCase.java,v $
// Revision 1.19  2002/11/07 20:55:39  eob
// Organize imports to remove unused imports.  Remove unused local variables.
//
// Revision 1.18  2002/10/30 23:04:20  eob
// Feature request [ 630127 ] Support /a/b[text()='foo']
// http://sourceforge.net/projects/sparta-xml/
//
// Revision 1.17  2002/09/19 21:04:04  eob
// Add support for position attribute in XPath.
//
// Revision 1.16  2002/08/20 18:24:55  eob
// Change from old sparta package names to new ones, following the
// release to SourceForge.
//
// Revision 1.15  2002/08/18 04:58:02  eob
// Sparta no longer throws XPathException -- it throws ParseException
// instead.
//
// Revision 1.14  2002/08/15 23:40:23  sermarti
//
// Revision 1.13  2002/08/15 23:01:55  eob
// Add test for bug in which index was not getting changed.
//
// Revision 1.12  2002/08/15 05:10:16  eob
// Add indexing tests.
//
// Revision 1.11  2002/07/08 22:39:21  eob
// Add test cases for xpathEnsure
//
// Revision 1.10  2002/06/21 00:30:04  eob
// Allow setting of text()
//
// Revision 1.9  2002/06/14 19:46:24  eob
// Add tests for "text()" in XPath.
//
// Revision 1.8  2002/06/04 05:30:42  eob
// Add test for predicate in middle.
//
// Revision 1.7  2002/05/23 21:20:30  eob
// Add some more tests.
//
// Revision 1.6  2002/05/11 00:16:00  eob
// Add tests of xpathSetAttributes
//
// Revision 1.5  2002/03/26 02:19:23  eob
// Add no parent test case with .. access.
//
// Revision 1.4  2002/02/15 21:21:19  eob
// Replace use of XPathAPI with xpathSelect methods
//
// Revision 1.3  2002/02/15 20:15:59  eob
// Add test for ../@lang
//
// Revision 1.2  2002/02/14 02:23:16  eob
// Handle attribute XPaths.
//
// Revision 1.1  2002/02/04 21:29:47  eob
// initial
