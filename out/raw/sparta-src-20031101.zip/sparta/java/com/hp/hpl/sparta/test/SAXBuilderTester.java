/*
 * Created on 01-Jun-2003 by eob
 */
package com.hp.hpl.sparta.test;

import java.io.*;

import javax.xml.parsers.*;

import junit.framework.TestCase;

import org.xml.sax.SAXException;

import com.hp.hpl.sparta.Document;
import com.hp.hpl.thermopylae.SAXBuilder;

/**
 * @version $Revision: 1.1 $
 * @author eob
 */
public class SAXBuilderTester extends TestCase {

    /**
     * @param arg0
     */
    public SAXBuilderTester(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }
     
    //public void testBasicDefault() throws ParserConfigurationException, SAXException, IOException{
    //    _testBasic( SAXParserFactory.newInstance().newSAXParser() );
    //}

    public void testBasicThermopylae() throws ParserConfigurationException, SAXException, IOException{
        System.setProperty("javax.xml.parsers.SAXParserFactory","com.hp.hpl.thermopylae.SAXParserFactoryImpl");
        _testBasic( SAXParserFactory.newInstance().newSAXParser() );
    }

    public void testBasicCrimson() throws ParserConfigurationException, SAXException, IOException{
        System.setProperty("javax.xml.parsers.SAXParserFactory","org.apache.crimson.jaxp.SAXParserFactoryImpl");
       _testBasic( SAXParserFactory.newInstance().newSAXParser() );
   }

    public void _testBasic(SAXParser parser) throws ParserConfigurationException, SAXException, IOException{
       SAXBuilder builder = new SAXBuilder();
        String xmlS = "<A><B>text<C/>more text</B></A>";
        InputStream xml = new ByteArrayInputStream(xmlS.getBytes()); 
        parser.parse(xml,builder);
        Document doc = builder.getParsedDocument();
        assertEquals( xmlS, doc.getDocumentElement().toXml());
    }

}



// $Log: SAXBuilderTester.java,v $
// Revision 1.1  2003/06/19 20:30:05  eobrain
// Unit test.
//