package com.hp.hpl.sparta.test;

import java.io.*;

import junit.framework.TestCase;

import com.hp.hpl.sparta.*;

/**
 *  Unit test of ParseByteStream
   <blockquote><small> Copyright (C) 2003 Hewlett-Packard Company.
   This file is part of Sparta, an XML Parser, DOM, and XPath library.
   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 2.1 of
   the License, or (at your option) any later version.  This library
   is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE. </small></blockquote>

   This class was originally created for testing ParseByteStream.fixEncoding().

   @version $Date: 2003/07/18 00:02:37 $
   @author Eamonn O'Brien-Strain, Yuhong Xiong
 */

public class ParseByteStreamTestCase extends TestCase {
    public ParseByteStreamTestCase(String name) {
        super(name);
    }

    public void testUTF8() throws IOException, ParseException {
        File xmlFile = new File("build/testData/p23pass2.xml");
        Document document =
            Parser.parse(xmlFile.toURL().toString(), new FileReader(xmlFile));
        Element root = document.getDocumentElement();
        String tag = root.getTagName();
        assertEquals("doc", tag);
    }

    public void testEUCJP() throws IOException, ParseException {
        File xmlFile = new File("build/testData/pr-xml-euc-jp.xml");
        Document document =
            Parser.parse(xmlFile.toURL().toString(), new FileReader(xmlFile));
        Element root = document.getDocumentElement();
        String tag = root.getTagName();
        assertEquals("spec", tag);
    }

    public void testMeta() throws IOException, ParseException {
        File xmlFile = new File("build/testData/.meta.xml");
        Document document =
            Parser.parse(xmlFile.toURL().toString(), new FileReader(xmlFile));
        Element root = document.getDocumentElement();
        String tag = root.getTagName();
        assertEquals("MetaData", tag);
    }
}
