package com.hp.hpl.sparta.test;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.*;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.*;

/**
 * Test examples at <a
   href="http://www.w3.org/TR/xpath#path-abbrev">W3C</a> using Xalan
   XPath as a test of the tests used for sparta and fatpath Xpath.

   <blockquote><small> Copyright (C) 2002 Hewlett-Packard Company.
   This file is part of Sparta, an XML Parser, DOM, and XPath library.
   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 2.1 of
   the License, or (at your option) any later version.  This library
   is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE. </small></blockquote>
   @version  $Date: 2002/10/30 23:18:43 $  $Revision: 1.9 $
   @author Eamonn O'Brien-Strain
 */

public class XalanTestCase extends W3cXPathTestCase {

    public XalanTestCase(String name)
        throws
            SAXException,
            IOException,
            ParserConfigurationException,
            NoSuchElementException {
        super(name);
    }

    public void testPara()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(section_1_1_, "para");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testStar()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(section_1_1_, "*");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testTextSingle()
        throws IOException, NoSuchElementException, TransformerException {
        Element para111 =
            (Element) XPathAPI.selectSingleNode(
                section_1_1_,
                "para[@type='error']");
        Text text111 = (Text) XPathAPI.selectSingleNode(para111, "text()");
        assertEquals(PARA_1_1_1, text111.getData());
    }

    public void testTextSplit()
        throws IOException, NoSuchElementException, TransformerException {
        Element para121 =
            (Element) XPathAPI.selectSingleNode(section_1_2_, "para");
        Text text121 = (Text) XPathAPI.selectSingleNode(para121, "text()");
        assertEquals(PARA_1_2_1a, text121.getData());

        NodeIterator nodes = XPathAPI.selectNodeIterator(para121, "text()");

        assertEquals(PARA_1_2_1a, ((Text) nodes.nextNode()).getData());
        assertEquals(PARA_1_2_1b, ((Text) nodes.nextNode()).getData());
        assertNull(nodes.nextNode());

    }

    public void testAttr()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(section_1_1_, "@name");

        Attr attr = (Attr) nodes.nextNode();
        assertEquals("Section 1.1", attr.getValue());
    }

    public void testParaPosn()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(section_1_1_, "para[1]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());
    }

    public void testStarPara()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(chapter_1_, "*/para");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testChapter5Section2()
        throws IOException, NoSuchElementException, TransformerException {
        Element element =
            (Element) XPathAPI.selectSingleNode(
                doc_[0],
                "/doc/chapter[5]/section[2]");

        assertEquals("Section 5.2", element.getAttribute("name"));
    }

    public void testChapterPara()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(
                doc_[0].getDocumentElement(),
                "chapter//para");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testAllPara()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(section_1_1_, "//para");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testAllOlistPara()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(doc_[0], "//olist/item");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(ITEM_1_2_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(ITEM_1_2_2, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testDot()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(section_1_1_, ".");

        Element element = (Element) nodes.nextNode();
        assertTrue(element == section_1_1_);

        assertNull(nodes.nextNode());
    }

    public void testDescendentPara()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(chapter_1_, ".//para");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testDotDot()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(section_1_1_, "..");

        Element element = (Element) nodes.nextNode();
        assertTrue(element == chapter_1_);

        assertNull(nodes.nextNode());
    }

    public void testDotDotSlashAttrLang()
        throws IOException, NoSuchElementException, TransformerException {
        Attr lang = (Attr) XPathAPI.selectSingleNode(chapter_1_, "../@lang");

        assertNotNull(lang);
        assertEquals("en", lang.getValue());
    }

    public void testParaTypeWarning()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(
                section_1_1_,
                "para[@type=\"warning\"]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testParaTypeNotWarning()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(
                section_1_1_,
                "para[@type!=\"warning\"]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testParaType()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(section_1_1_, "para[@type]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertNull(nodes.nextNode());
    }

    public void testAbs()
        throws IOException, NoSuchElementException, TransformerException {
        Element element =
            (Element) XPathAPI.selectSingleNode(
                doc_[0],
                "/doc/chapter/section[@name='Section 1.2']");

        assertEquals("Section 1.2", element.getAttribute("name"));

    }

    public void testDocRel()
        throws IOException, NoSuchElementException, TransformerException {
        Element element =
            (Element) XPathAPI.selectSingleNode(
                doc_[0],
                "doc/chapter/section[@name='Section 1.2']");

        assertEquals("Section 1.2", element.getAttribute("name"));

    }

    public void testEquivalence()
        throws IOException, NoSuchElementException, TransformerException {
        Element e1 =
            (Element) XPathAPI.selectSingleNode(
                doc_[0],
                "/doc/chapter/section[@name='Section 1.2']");
        Element e2 =
            (Element) XPathAPI.selectSingleNode(
                doc_[0],
                "doc/chapter/section[@name='Section 1.2']");
        Element e3 =
            (Element) XPathAPI.selectSingleNode(
                doc_[0].getDocumentElement(),
                "chapter/section[@name='Section 1.2']");

        assertNotNull(e1);
        assertTrue(e1 == e2);
        assertTrue(e1 == e3);
    }

    public void testFromDoc1()
        throws IOException, NoSuchElementException, TransformerException {
        Element element =
            (Element) XPathAPI.selectSingleNode(doc_[0], "doc/chapter");
        assertNotNull(element);
        assertEquals("Chapter 1", element.getAttribute("name"));

    }

    public void testFromDoc2()
        throws IOException, NoSuchElementException, TransformerException {
        Element element =
            (Element) XPathAPI.selectSingleNode(
                doc_[0],
                "doc/chapter/section[@name='Section 1.2']");

        assertEquals("Section 1.2", element.getAttribute("name"));

    }

    public void testMetadata()
        throws IOException, NoSuchElementException, TransformerException {
        Element a =
            (Element) XPathAPI.selectSingleNode(
                doc_[1],
                "/MetaData/Child[@name='public']");
        Element b =
            (Element) XPathAPI.selectSingleNode(a, "*[@expires-offset]");
        assertNull(b);

    }

    public void testMetadataRel()
        throws IOException, NoSuchElementException, TransformerException {
        Element a =
            (Element) XPathAPI.selectSingleNode(
                doc_[1],
                "MetaData/Child[@name='public']");
        Element b =
            (Element) XPathAPI.selectSingleNode(a, "*[@expires-offset]");
        assertNull(b);

    }

    public void testBadNoParent()
        throws IOException, NoSuchElementException, TransformerException {
        Element element = (Element) XPathAPI.selectSingleNode(doc_[0], "../*");
        assertNull(element);
    }

    public void testPredicateInMiddle()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(
                doc_[0],
                "/doc/chapter/section[@name='Section 1.1']/para");

        Element para1 = (Element) nodes.nextNode();
        assertNotNull(para1);
        Text text1 = (Text) para1.getFirstChild();
        assertEquals(PARA_1_1_1, text1.getData());

        Element para2 = (Element) nodes.nextNode();
        assertNotNull(para2);
        Text text2 = (Text) para2.getFirstChild();
        assertEquals(PARA_1_1_2, text2.getData());

        assertNull(nodes.nextNode());

    }

    public void testParaPosn2()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(section_1_1_, "para[2]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());
    }

    public void testPosition1()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(
                doc_[0],
                "/doc/chapter/section/para[1]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        para = (Element) nodes.nextNode();
        assertNull(para);

    }

    public void testPosition2()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(
                doc_[0],
                "/doc/chapter/section/para[2]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        para = (Element) nodes.nextNode();
        assertNull(para);

    }

    public void testSlashSlashParaPosn1()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(doc_[0], "//para[1]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        para = (Element) nodes.nextNode();
        assertNull(para);

    }

    public void testSlashSlashParaPosn2()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(doc_[0], "//para[2]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        para = (Element) nodes.nextNode();
        assertNull(para);

    }

    public void testDotPosn()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(section_1_1_, "self::node()[1]");

        Element element = (Element) nodes.nextNode();
        assertTrue(element == section_1_1_);

        assertNull(nodes.nextNode());
    }

    public void testDotDotPosn()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(section_1_1_, "parent::node()[1]");

        Element element = (Element) nodes.nextNode();
        assertTrue(element == chapter_1_);

        assertNull(nodes.nextNode());
    }

    public void testStarPosn()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(section_1_1_, "*[1]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());
    }

    public void testStarPosn2()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(section_1_1_, "*[2]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());
    }

    public void testStarPosition1()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(doc_[0], "/doc/chapter/section/*[1]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_2_1a, text.getData());

        para = (Element) nodes.nextNode();
        assertEquals("nlist", para.getTagName());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        para = (Element) nodes.nextNode();
        assertNull(para);

    }

    public void testStarPosition2()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(doc_[0], "/doc/chapter/section/*[2]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextNode();
        assertEquals("olist", para.getTagName());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        para = (Element) nodes.nextNode();
        assertNull(para);

    }

    public void testSlashSlashStarPosn1()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(doc_[0], "//*[1]");

        Element element = (Element) nodes.nextNode();
        assertEquals("doc", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("chapter", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("section", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("br", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("item", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("nlist", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("item", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("section", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("section", element.getTagName());

        element = (Element) nodes.nextNode();
        assertNull(element);

    }

    public void testSlashSlashStarPosn2()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes = XPathAPI.selectNodeIterator(doc_[0], "//*[2]");

        Element element = (Element) nodes.nextNode();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("section", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("olist", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("item", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("item", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("chapter", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("para", element.getTagName());

        element = (Element) nodes.nextNode();
        assertEquals("section", element.getTagName());

        element = (Element) nodes.nextNode();
        assertNull(element);

    }

    public void testText()
        throws IOException, NoSuchElementException, TransformerException {
        Text text111 =
            (Text) XPathAPI.selectSingleNode(
                section_1_1_,
                "para[@type='error']/text()");
        assertEquals(PARA_1_1_1, text111.getData());
    }

    public void testTextExists()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator i =
            XPathAPI.selectNodeIterator(section_1_1_, "para[text()]");
        Element para = (Element) i.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) i.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertNull(i.nextNode());
    }

    public void testTextEquals()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator i =
            XPathAPI.selectNodeIterator(
                section_1_1_,
                "para[text()='" + PARA_1_1_1 + "']");
        Element para = (Element) i.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        assertNull(i.nextNode());
    }

    public void testTextNotEquals()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator i =
            XPathAPI.selectNodeIterator(
                section_1_1_,
                "para[text()!='" + PARA_1_1_1 + "']");
        Element para = (Element) i.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        assertNull(i.nextNode());
    }

    public void testLessThan()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(
                doc_[0],
                "/doc/*/section/para[@count<6]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_1_1_2, text.getData());

        para = (Element) nodes.nextNode();
        assertNull(para);

    }

    public void testGreaterThan()
        throws IOException, NoSuchElementException, TransformerException {
        NodeIterator nodes =
            XPathAPI.selectNodeIterator(
                doc_[0],
                "/doc/*/section/para[@count>16]");

        Element para = (Element) nodes.nextNode();
        Text text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_1, text.getData());

        para = (Element) nodes.nextNode();
        text = (Text) para.getFirstChild();
        assertEquals(PARA_2_1_2, text.getData());

        para = (Element) nodes.nextNode();
        assertNull(para);

    }

}

class EchoErrorHandler implements ErrorHandler {

    public void error(SAXParseException e) {
        message(e, "ERROR");
    }
    public void fatalError(SAXParseException e) throws SAXParseException {
        message(e, "ERROR");
        throw e;
    }
    public void warning(SAXParseException e) {
        message(e, "WARNING");
    }

    private void message(SAXParseException e, String level) {
        System.out.println(
            e.getSystemId()
                + " ("
                + e.getLineNumber()
                + "): "
                + e.getMessage()
                + " ("
                + level
                + ")");
    }

}
