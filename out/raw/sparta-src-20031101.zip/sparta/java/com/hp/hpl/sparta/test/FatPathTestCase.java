package com.hp.hpl.sparta.test;

import java.io.IOException;
import java.util.Enumeration;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import com.hp.hpl.sparta.xpath.XPathException;
import com.hp.hpl.thermopylae.fatpath.XPathAPI;


/**
 * Unit test of FatPath.
   <blockquote><small> Copyright (C) 2002 Hewlett-Packard Company.
   This file is part of Sparta, an XML Parser, DOM, and XPath library.
   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 2.1 of
   the License, or (at your option) any later version.  This library
   is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE. </small></blockquote>
   @version  $Date: 2002/10/30 23:18:43 $  $Revision: 1.9 $
   @author Eamonn O'Brien-Strain
 */

public class FatPathTestCase extends W3cXPathTestCase {

    public FatPathTestCase(String name)
      throws SAXException,
             IOException,
             ParserConfigurationException,
             NoSuchElementException
    {
        super(name);
    }

    public void testPara()
        throws IOException, NoSuchElementException, XPathException
    {

        Enumeration nodes = XPathAPI.selectElementIterator(section_1_1_,
                                                           "para");

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testStar()
        throws XPathException, IOException, NoSuchElementException
    {

        Enumeration nodes = XPathAPI.selectElementIterator(section_1_1_,"*");

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testTextSingle()
        throws IOException, NoSuchElementException, XPathException
    {
        Element para111
           = (Element)XPathAPI.selectSingleElement(section_1_1_,"para[@type='error']");
        String text111 = XPathAPI.selectSingleString(para111,"text()");
        assertEquals( PARA_1_1_1, text111 );
    }

    public void testTextSplit()
        throws IOException, NoSuchElementException, XPathException
    {
        Element para121
           = (Element)XPathAPI.selectSingleElement(section_1_2_,"para");
        String text121 = XPathAPI.selectSingleString(para121,"text()");
        assertEquals( PARA_1_2_1a, text121 );

       Enumeration nodes = XPathAPI.selectStringIterator(para121,"text()");

       assertEquals( PARA_1_2_1a, nodes.nextElement() );
       assertEquals( PARA_1_2_1b, nodes.nextElement() );
       assertTrue( !nodes.hasMoreElements() );

    }

     public void testAttr()
        throws IOException, NoSuchElementException, XPathException
    {
        String value = XPathAPI.selectSingleString(section_1_1_,"@name");
        assertEquals( "Section 1.1", value );
    }

    public void testPara1()
        throws IOException, NoSuchElementException, XPathException
    {
        Element para = XPathAPI.selectSingleElement(section_1_1_,"para[1]");
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );
    }

    public void testStarPara()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes = XPathAPI.selectElementIterator(chapter_1_,
                                                           "*/para");

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_2_1a, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testChapter5Section2()
        throws IOException, NoSuchElementException, XPathException
    {
        Element element = XPathAPI.selectSingleElement(doc_[0],
                                  "/doc/chapter[5]/section[2]");

        assertEquals( "Section 5.2", element.getAttribute("name") );
    }

    public void testChapterPara()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(doc_[0].getDocumentElement(),
                                            "chapter//para");

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_2_1a, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_2, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testAllPara()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(doc_[0].getDocumentElement(),
                                            "chapter//para");

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_2_1a, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_2, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testAllOlistPara()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(doc_[0],"//olist/item");

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        assertNotNull( para );
        Text text = (Text)para.getFirstChild();
        assertEquals( ITEM_1_2_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( ITEM_1_2_2, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testDot()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(section_1_1_,".");

        assertTrue( nodes.hasMoreElements() );
        Element element = (Element)nodes.nextElement();
        assertTrue( element == section_1_1_ );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testDescendentPara()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator( chapter_1_, ".//para" );

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_2_1a, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testDotDot()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(section_1_1_,"..");

        assertTrue( nodes.hasMoreElements() );
        Element element = (Element)nodes.nextElement();
        assertTrue( element == chapter_1_ );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testDotDotSlashAttrLang()
        throws IOException, NoSuchElementException, XPathException
    {
        String lang = XPathAPI.selectSingleString(chapter_1_,"../@lang");

        assertEquals( "en", lang );
    }

    public void testParaTypeWarning()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(section_1_1_,
                                            "para[@type=\"warning\"]");

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testParaTypeNotWarning()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(section_1_1_,
                                            "para[@type!=\"warning\"]");

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testParaType()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(section_1_1_,"para[@type]");

        assertTrue( nodes.hasMoreElements() );
        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        assertTrue( nodes.hasMoreElements() );
        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testAbs()
        throws IOException, NoSuchElementException, XPathException
    {
        Element element
           = (Element)XPathAPI.selectSingleElement(doc_[0],
                                                   "/doc/chapter/section[@name='Section 1.2']");

        assertNotNull( element );
        assertEquals( "Section 1.2", element.getAttribute("name") );

    }

    public void testFromDoc1()
        throws IOException, NoSuchElementException, XPathException
    {
        Element element
           = (Element)XPathAPI.selectSingleElement(doc_[0],"doc/chapter");
        assertNotNull( element );
        assertEquals( "Chapter 1", element.getAttribute("name") );

    }

    public void testFromDoc2()
        throws IOException, NoSuchElementException, XPathException
    {
        Element element
           = XPathAPI.selectSingleElement(doc_[0],
                                                   "doc/chapter/section[@name='Section 1.2']");

        assertNotNull( element );
        assertEquals( "Section 1.2", element.getAttribute("name") );

    }

    public void testMetadata()
        throws IOException, NoSuchElementException, XPathException
    {
        Element a
           = XPathAPI.selectSingleElement(doc_[1],
                                                "/MetaData/Child[@name='public']");
        assertNotNull( a );
        Element b = XPathAPI.selectSingleElement(a,
                                                          "*[@expires-offset]"
                                                          );
        assertNull( b );

    }

    public void testBadNoParent()
        throws IOException, NoSuchElementException
    {
        try{
            XPathAPI.selectSingleElement(doc_[0], "../*");
            fail("Expected exception was not thrown.");
        }catch(XPathException e){
            //This was expected.  Do nothing.
        }
    }

    public void testPredicateInMiddle()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(
                    doc_[0],
                    "/doc/chapter/section[@name='Section 1.1']/para"
                   );

        Element para1 = (Element)nodes.nextElement();
        assertNotNull(para1);
        Text text1 = (Text)para1.getFirstChild();
        assertEquals( PARA_1_1_1, text1.getData() );

        Element para2 = (Element)nodes.nextElement();
        assertNotNull(para2);
        Text text2 = (Text)para2.getFirstChild();
        assertEquals( PARA_1_1_2, text2.getData() );

        assertTrue( !nodes.hasMoreElements() );

    }

    public void testPara4()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes = XPathAPI.selectElementIterator(doc_[0],
                                  "/doc/chapter/section/para[4]");

        assertTrue( !nodes.hasMoreElements() );
    }


    public void testPara2()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes = XPathAPI.selectElementIterator(section_1_1_,
                                  "para[2]");

        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );
    }

    public void testPosition1()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes = XPathAPI.selectElementIterator(doc_[0],
                                  "/doc/chapter/section/para[1]");

        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_2_1a, text.getData() );

        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_1, text.getData() );

       assertTrue( !nodes.hasMoreElements() );

    }


    public void testPosition2()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes = XPathAPI.selectElementIterator(doc_[0],
                                  "/doc/chapter/section/para[2]");

        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_2, text.getData() );

       assertTrue( !nodes.hasMoreElements() );

    }

    public void testSlashSlashPara1()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes = XPathAPI.selectElementIterator(doc_[0],
                                  "//para[1]");

        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_2_1a, text.getData() );

        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_1, text.getData() );

       assertTrue( !nodes.hasMoreElements() );

    }


    public void testSlashSlashPara2()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes = XPathAPI.selectElementIterator(doc_[0],
                                  "//para[2]");

        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_2, text.getData() );

       assertTrue( !nodes.hasMoreElements() );

    }

    public void testDotPosn()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(section_1_1_,".[1]");

        assertTrue( nodes.hasMoreElements() );
        Element element = (Element)nodes.nextElement();
        assertTrue( element == section_1_1_ );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testDotDotPosn()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes
           = XPathAPI.selectElementIterator(section_1_1_,"..[1]");

        assertTrue( nodes.hasMoreElements() );
        Element element = (Element)nodes.nextElement();
        assertTrue( element == chapter_1_ );

        assertTrue( !nodes.hasMoreElements() );
    }

    public void testText()
        throws IOException, NoSuchElementException, XPathException
    {
        String text111 = XPathAPI.selectSingleString(section_1_1_,
                                        "para[@type='error']/text()");
        assertEquals( PARA_1_1_1, text111 );
    }

    public void testTextExists()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration i = XPathAPI.selectElementIterator(section_1_1_,
                                        "para[text()]");
        Element para = (Element)i.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        para = (Element)i.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( !i.hasMoreElements() );
    }

    public void testTextEquals()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration i = XPathAPI.selectElementIterator(section_1_1_,
                                        "para[text()='"+PARA_1_1_1+"']");
        Element para = (Element)i.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        assertTrue( !i.hasMoreElements() );
    }

    public void testTextNotEquals()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration i = XPathAPI.selectElementIterator(section_1_1_,
                                        "para[text()!='"+PARA_1_1_1+"']");
        Element para = (Element)i.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( !i.hasMoreElements() );
    }

    public void testLessThan()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes = XPathAPI.selectElementIterator(doc_[0],
                                  "/doc/*/section/para[@count<6]");

        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_1, text.getData() );

        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_1_1_2, text.getData() );

        assertTrue( !nodes.hasMoreElements() );

    }

    public void testGreaterThan()
        throws IOException, NoSuchElementException, XPathException
    {
        Enumeration nodes = XPathAPI.selectElementIterator(doc_[0],
                                  "/doc/*/section/para[@count>16]");

        Element para = (Element)nodes.nextElement();
        Text text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_1, text.getData() );

        para = (Element)nodes.nextElement();
        text = (Text)para.getFirstChild();
        assertEquals( PARA_2_1_2, text.getData() );

        assertTrue( !nodes.hasMoreElements() );

    }


}

// $Log: FatPathTestCase.java,v $
// Revision 1.9  2002/11/07 20:55:23  eob
// Organize imports to remove unused imports.  Remove unused local variables.
//
// Revision 1.8  2002/10/30 22:56:59  eob
// Add test for new [text()='foo'] feature.
//
// Revision 1.7  2002/09/19 21:04:45  eob
// Add support for position attribute in XPath.
//
// Revision 1.6  2002/08/20 18:22:34  eob
// Change from old sparta package names to new ones, following the
// release to SourceForge.
//
// Revision 1.5  2002/06/14 19:44:32  eob
// Add tests for "text()" in XPath.
//
// Revision 1.4  2002/06/04 05:30:10  eob
// Add test for predicate in middle.
//
// Revision 1.3  2002/03/26 01:53:57  eob
// Add no parent test case with .. access.
//
// Revision 1.2  2002/02/15 20:16:32  eob
// Add test for ../@lang
//
// Revision 1.1  2002/02/04 21:33:24  eob
// initial
