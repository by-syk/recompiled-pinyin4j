package com.hp.hpl.sparta.test;

import java.io.CharArrayReader;
import java.io.IOException;

import javax.xml.parsers.*;

import org.w3c.dom.*;
import org.xml.sax.*;

/**
 *
 * Stuff common to FatPath and Xalan test cases.
   <blockquote><small> Copyright (C) 2002 Hewlett-Packard Company.
   This file is part of Sparta, an XML Parser, DOM, and XPath library.
   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 2.1 of
   the License, or (at your option) any later version.  This library
   is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE. </small></blockquote>
   @version  $Date: 2002/10/30 23:18:43 $  $Revision: 1.9 $
   @author Eamonn O'Brien-Strain
 */

public abstract class W3cXPathTestCase extends XPathTestCase {

    protected W3cXPathTestCase(String name)
        throws SAXException,
               IOException,
               ParserConfigurationException,
               NoSuchElementException
    {
        super(name);

        for(int i=0; i<XML.length; ++i){
            DocumentBuilder parser
                = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            ErrorHandler eh = new EchoErrorHandler();
            parser.setErrorHandler(eh);
            InputSource src = new InputSource(new CharArrayReader(XML[i].toCharArray()));
            doc_[i] = parser.parse(src);
        }

        chapter_1_ = firstChildElement( doc_[0].getDocumentElement() );
        section_1_1_ = firstChildElement(  chapter_1_ );
        section_1_2_ = nextSiblingElement( section_1_1_ );
    }

    protected final Document[] doc_ = new Document[XML.length];
    protected final Element chapter_1_, section_1_1_, section_1_2_;

    //////////////////////////////////////////////////////////////////////

    static protected Element firstChildElement(Element parent)
        throws NoSuchElementException
    {
        for( Node n=parent.getFirstChild(); n!=null; n=n.getNextSibling() )
            if( n instanceof Element )
                return (Element)n;
        throw new NoSuchElementException();
    }

    static protected Element nextSiblingElement(Element prev)
        throws NoSuchElementException
    {
        for( Node n=prev.getNextSibling(); n!=null; n=n.getNextSibling() )
            if( n instanceof Element )
                return (Element)n;
        throw new NoSuchElementException();
    }

}
