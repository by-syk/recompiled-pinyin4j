import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.hp.hpl.sparta.*;
import com.hp.hpl.sparta.xpath.XPathException;

/**
 * Run sparta unit tests.  This java application takes no command line
 * arguments.  It will run all the Junit testcases and pop up a window
 * displaying the results.  It reads the list of test to be executed
 * from the "junit" target of the agile/build.xml ant build file.  If
 * you want a non-interactive regression test run ant with target
 * "junit" on the top level build file.  This class can also be
 * executed as a JUnit execution within Eclipse.
 *
   <blockquote><small> Copyright (C) 2002 Hewlett-Packard Company.
   This file is part of Sparta, an XML Parser, DOM, and XPath library.
   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 2.1 of
   the License, or (at your option) any later version.  This library
   is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE. </small></blockquote>
   @version  $Date: 2002/10/30 23:18:43 $  $Revision: 1.9 $
   @author Eamonn O'Brien-Strain
 */

public class SpartaTestSuite extends TestSuite {

    public static Test suite()
        throws
            ParseException,
            XPathException,
            IOException,
            IllegalAccessException,
            InstantiationException,
            NoSuchMethodException,
            InvocationTargetException,
            ClassNotFoundException {
        TestSuite suite = new TestSuite();

        String buildFile = System.getProperty("agile.build.file");
        if (buildFile == null)
            buildFile = "build.xml";
        System.out.println("Reading test cases from build file: " + buildFile);

        Document antBuild = Parser.parse(buildFile, new FileReader(buildFile));
        Enumeration i =
            antBuild.xpathSelectStrings(
                "/project/target[@name='junit']/junit/test/@name");
        while (i.hasMoreElements()) {
            String className = (String) i.nextElement();
            Class clazz = Class.forName(className);
            try {
                Method testMaker = clazz.getMethod("suite", C_NOARGS);
                suite.addTest((Test) testMaker.invoke(null, O_NOARGS));
            } catch (Exception e) {
                suite.addTest(new TestSuite(clazz));
            }
        }
        return suite;
    }

    static private Class[] C_NOARGS = {
    };
    static private Object[] O_NOARGS = {
    };

    /** Invokes Junit to run the tests. If the first argument is
     *  <i>-textUI</i>, invoke the text version of the test runner; Otherwise,
     *  invoke the GUI version.
     *  @param args Command line arguments. Currently, only check whether the
     *   first argument is <i>-textUI</i>.
     */
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("-textUI")) {
                junit.textui.TestRunner.main( new String[]{
                "-noloading",
                SpartaTestSuite.class.getName()
            } );
        } else {
                junit.swingui.TestRunner.main( new String[]{
                "-noloading",
                SpartaTestSuite.class.getName()
            } );
        }
    }
}
