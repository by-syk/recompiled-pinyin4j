import java.io.*;
import java.util.Enumeration;

import com.hp.hpl.sparta.*;

/*
 * Created on 30-Jun-2003 by eob
 */

/** An example handler that simply echoes out the XML.
 * It does not properly encode characters in text nodes and attributes.
 * It always oututs empty elements as "<foo></foo>" instead of "<foo/>"
 */
class Handler implements ParseHandler {

    private ParseSource parseSource_ = null;
    private final Writer writer_ = new OutputStreamWriter(System.out);

    public void characters(char[] buf, int offset, int len)
        throws ParseException {
        try {

            //ignore encoding issues
            writer_.write(buf, offset, len);

        } catch (IOException e) {
            throw new ParseException(e.getMessage(), e);
        }
    }

    public void endDocument() throws ParseException {
        try {

            writer_.flush();

        } catch (IOException e) {
            throw new ParseException(e.getMessage(), e);
        }
    }

    public void endElement(Element element) throws ParseException {
        try {

            writer_.write("</" + element.getTagName() + ">");

        } catch (IOException e) {
            throw new ParseException(e.getMessage(), e);
        }
    }

    public ParseSource getParseSource() {
        return parseSource_;
    }

    public void setParseSource(ParseSource ps) {
        parseSource_ = ps;
    }

    public void startDocument() throws ParseException {
        try {

            writer_.write("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n");

        } catch (IOException e) {
            throw new ParseException(e.getMessage(), e);
        }
    }

    public void startElement(Element element) throws ParseException {
        try {

            writer_.write("<" + element.getTagName());
            for (Enumeration i = element.getAttributeNames();
                i.hasMoreElements();
                ) {
                String name = (String) i.nextElement();
                String value = element.getAttribute(name);
                writer_.write(" " + name + "\"" + value + "\"");
                //ignore encoding
            }
            writer_.write(">");

        } catch (IOException e) {
            throw new ParseException(e.getMessage(), e);
        }
    }

}

/**
 * @version $Revision: 1.2 $
 * @author eob
 */
public class SaxExample {

    public static void main(String[] args) throws IOException, ParseException {

        if (args.length != 0)
            throw new Error("USAGE: java SaxExample");

        Handler handler = new Handler();
        Parser.parse(
            "example",
            new InputStreamReader(new ByteArrayInputStream(XML)),
            handler);

    }

    static private byte[] XML =
        ("\n"
            + "<!DOCTYPE project SYSTEM \"file:project.dtd\">\n"
            + "\n"
            + "<project name=\"agile\" default=\"jar\" basedir=\".\">\n"
            + "\n"
            + "  <property file=\"build.properties\"/>\n"
            + "  <property name=\"SRC\"     value=\"java\"/>\n"
            + "  <property name=\"CLASSES\" value=\"j2seclasses\"/>\n"
            + "  <property name=\"J2MECLASSES\" value=\"j2meclasses\"/>\n"
            + "  <property name=\"LIB\"     value=\"lib\"/>\n"
            + "  <property name=\"DOC\"     value=\"doc\"/>\n"
            + "  <property name=\"BUILD\"   value=\"build\"/>\n"
            + "  <property name=\"RELEASE\" value=\"../release\"/>\n"
            + "\n"
            + "  <path id=\"CLASSPATH\">\n"
            + "    <pathelement location=\"${BUILD}/lib/junit.jar\"/>\n"
            + "  </path>\n"
            + "\n"
            + "  <path id=\"J2MEBOOTCLASSPATH\">\n"
            + "    <pathelement location=\"${BUILD}/lib/j2me-classes.zip\"/>\n"
            + "  </path>\n"
            + "\n"
            + "  <target name=\"-init.init\">\n"
            + "    <condition property=\"isWindows\">\n"
            + "      <os family=\"windows\"/>\n"
            + "    </condition>\n"
            + "  </target>\n"
            + "  <target name=\"-init.windows\" if=\"isWindows\">\n"
            + "    <property name=\"view.html.cmd\" value=\"cmd\"/>\n"
            + "    <property name=\"view.html.args\" value=\"/c start\"/>\n"
            + "  </target>\n"
            + "  <target name=\"-init.unix\" unless=\"isWindows\">\n"
            + "    <property name=\"view.html.cmd\" value=\"${basedir}/build/bin/view-html\"/>\n"
            + "    <property name=\"view.html.args\" value=\" \"/>\n"
            + "  </target>\n"
            + "  <target name=\"-init\" depends=\"-init.init, -init.windows, -init.unix\">\n"
            + "    <tstamp/>\n"
            + "  </target>\n"
            + "  <target name=\"-proguard.taskdef\">\n"
            + "    <taskdef name=\"proguard\"\n"
            + "             classname=\"proguard.ant.ProGuardTask\"\n"
            + "             classpath=\"build/lib/proguard.jar\" />\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"compile\"\n"
            + "    description=\"Compile all the Java code\"\n"
            + "  >\n"
            + "      <echo message=\"VMVERSION=${VMVERSION}\"/>\n"
            + "      <mkdir dir=\"${CLASSES}\"/>\n"
            + "      <javac srcdir=\"${SRC}\"\n"
            + "             destdir=\"${CLASSES}\"\n"
            + "             classpathref=\"CLASSPATH\"\n"
            + "             deprecation=\"on\"\n"
            + "         debug=\"off\"\n"
            + "         optimize=\"on\"\n"
            + "         target=\"${VMVERSION}\"\n"
            + "             />\n"
            + "  </target> \n"
            + "\n"
            + "  <target name=\"j2me-compile\"\n"
            + "    description=\"Compile all the Java code for J2ME\"\n"
            + "  >\n"
            + "      <echo message=\"VMVERSION=${VMVERSION}\"/>\n"
            + "      <mkdir dir=\"${J2MECLASSES}\"/>\n"
            + "      <javac srcdir=\"${SRC}\"\n"
            + "             destdir=\"${J2MECLASSES}\"\n"
            + "             bootclasspathref=\"J2MEBOOTCLASSPATH\"\n"
            + "             classpathref=\"CLASSPATH\"\n"
            + "             deprecation=\"on\"\n"
            + "         debug=\"off\"\n"
            + "         optimize=\"on\"\n"
            + "         target=\"${VMVERSION}\"\n"
            + "             >\n"
            + "        <exclude name=\"SpartaTestSuite.java\"/>\n"
            + "        <!--exclude name=\"SaxExample.java\"/-->\n"
            + "        <exclude name=\"**/test/**\"/>\n"
            + "        <exclude name=\"javax/**\"/>\n"
            + "        <exclude name=\"org/**\"/>\n"
            + "        <exclude name=\"**/thermopylae/**\"/>\n"
            + "      </javac>\n"
            + "  </target> \n"
            + "\n"
            + "  <target name=\"javadoc\" depends=\"-init\"\n"
            + "    description=\"Java API documentation\"\n"
            + "  >\n"
            + "    <mkdir dir=\"${DOC}\"/>\n"
            + "    <mkdir dir=\"${DOC}/api\"/>\n"
            + "    <javadoc sourcepath=\"${SRC}\"\n"
            + "      destdir=\"${DOC}/api\"\n"
            + "      packagenames=\"com.hp.hpl.*\"\n"
            + "      excludepackagenames=\"*.*.*.*.test\"\n"
            + "      version=\"true\"\n"
            + "      author=\"true\"\n"
            + "      use=\"true\"\n"
            + "      >\n"
            + "      <link\n"
            + "        href=\"http://java.sun.com/j2se/1.4/docs/api/\"\n"
            + "        />\n"
            + "      <link\n"
            + "        href=\"http://xml.apache.org/xalan-j/apidocs/\"\n"
            + "        />\n"
            + "      <!--link\n"
            + "        offline=\"true\"\n"
            + "        href=\"http://java.sun.com/j2se/1.4/docs/api/\"\n"
            + "        packagelistLoc=\"build/package-lists/jdk/\"\n"
            + "        />\n"
            + "      <link\n"
            + "        offline=\"true\"\n"
            + "        href=\"http://xml.apache.org/xalan-j/apidocs/\"\n"
            + "        packagelistLoc=\"build/package-lists/xalan/\"\n"
            + "        /-->\n"
            + "        <tag name=\"stereotype\" description=\"Stereotype:\" enabled=\"yes\"/>\n"
            + "        <tag name=\"precondition\" description=\"Precondition:\" enabled=\"yes\"/>\n"
            + "        <tag name=\"todo\" description=\"&lt;font color='red'>TODO:&lt;/font>\" enabled=\"yes\"/>\n"
            + "        <tag name=\"label\" description=\" \" enabled=\"yes\"/>\n"
            + "        <tag name=\"associates\" description=\"Precondition:\" enabled=\"yes\"/>\n"
            + "    </javadoc>             \n"
            + "    <exec executable=\"${view.html.cmd}\">\n"
            + "      <arg line=\"${view.html.args} ${DOC}/api/overview-summary.html\"/>\n"
            + "    </exec>\n"
            + "  </target> \n"
            + "\n"
            + "  <target name=\"jar\" depends=\"compile, -proguard.taskdef\"\n"
            + "    description=\"Create jar files\"\n"
            + "  >\n"
            + "    <mkdir dir=\"${LIB}\"/>\n"
            + "    <delete failonerror=\"no\" file=\"${LIB}/sparta.jar\"/>\n"
            + "    <jar\n"
            + "      jarfile=\"${LIB}/sparta.jar\"\n"
            + "      basedir=\"${CLASSES}\"\n"
            + "    >\n"
            + "      <include name=\"com/hp/hpl/sparta/*.class\"/>\n"
            + "      <include name=\"com/hp/hpl/sparta/xpath/*.class\"/>\n"
            + "    </jar>\n"
            + "    <delete failonerror=\"no\" file=\"${LIB}/thermopylae.jar\"/>\n"
            + "    <jar\n"
            + "      jarfile=\"${LIB}/thermopylae.jar\"\n"
            + "      basedir=\"${CLASSES}\"\n"
            + "    >\n"
            + "      <include name=\"com/hp/hpl/sparta/*.class\"/>\n"
            + "      <include name=\"com/hp/hpl/sparta/xpath/*.class\"/>\n"
            + "      <include name=\"com/hp/hpl/thermopylae/*.class\"/>\n"
            + "      <include name=\"com/hp/hpl/thermopylae/fatpath/*.class\"/>\n"
            + "      <include name=\"org/w3c/dom/*.class\"/>\n"
            + "      <metainf dir=\"${SRC}/META-INF\">\n"
            + "        <include name=\"services/*\"/>\n"
            + "      </metainf>\n"
            + "    </jar>\n"
            + "    <delete failonerror=\"no\" file=\"lib/sax.jar\"/>\n"
            + "    <mkdir dir=\"empty\"/>\n"
            + "    <proguard\n"
            + "      outjar=\"lib/sax.jar\"\n"
            + "      printusage=\"sax.deadcode\"\n"
            + "      obfuscate=\"no\"\n"
            + "      printseeds=\"sax.seeds\"\n"
            + "    >\n"
            + "      <libraryjar name=\"${java.home}/lib/rt.jar\"/>\n"
            + "      <libraryjar name=\"${BUILD}/lib/junit.jar\"/>\n"
            + "      <resourcejar name=\"empty\"/>\n"
            + "      <injar name=\"${CLASSES}\"/>\n"
            + "      <keep access=\"public\" type=\"class\" name=\"com.hp.hpl.sparta.Parser\">\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.Reader,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.Reader,com.hp.hpl.sparta.ParseLog,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.io.File,com.hp.hpl.sparta.ParseLog,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.io.File,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(char[],com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <!--method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(byte[],com.hp.hpl.sparta.ParseHandler)\"/-->\n"
            + "        <!--method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.InputStream,com.hp.hpl.sparta.ParseLog,com.hp.hpl.sparta.ParseHandler)\"/-->\n"
            + "        <!--method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.InputStream,com.hp.hpl.sparta.ParseHandler)\"/-->\n"
            + "        <!--method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.InputStream,com.hp.hpl.sparta.ParseLog,java.lang.String,com.hp.hpl.sparta.ParseHandler)\"/-->\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.Reader,com.hp.hpl.sparta.ParseLog,java.lang.String,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "      </keep>\n"
            + "      <keep access=\"public\" type=\"class\" name=\"com.hp.hpl.sparta.Element\">\n"
            + "        <method access=\"public\"\n"
            + "                type=\"java.util.Enumeration\"\n"
            + "                name=\"getAttributeNames()\"/>\n"
            + "      </keep>\n"
            + "    </proguard>\n"
            + "    <delete dir=\"empty\"/>\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"j2me-jar\" depends=\"j2me-compile, -proguard.taskdef\"\n"
            + "    description=\"Create J2ME versions of jar files\"\n"
            + "  >\n"
            + "    <mkdir dir=\"${LIB}\"/>\n"
            + "    <delete failonerror=\"no\" file=\"${LIB}/j2me-sparta.jar\"/>\n"
            + "    <jar\n"
            + "      jarfile=\"${LIB}/j2me-sparta.jar\"\n"
            + "      basedir=\"${J2MECLASSES}\"\n"
            + "    >\n"
            + "      <include name=\"com/hp/hpl/sparta/*.class\"/>\n"
            + "      <include name=\"com/hp/hpl/sparta/xpath/*.class\"/>\n"
            + "    </jar>\n"
            + "    <delete failonerror=\"no\" file=\"lib/j2me-sax.jar\"/>\n"
            + "    <mkdir dir=\"empty\"/>\n"
            + "    <proguard\n"
            + "      outjar=\"lib/j2me-sax.jar\"\n"
            + "      printusage=\"sax.deadcode\"\n"
            + "      obfuscate=\"no\"\n"
            + "      printseeds=\"sax.seeds\"\n"
            + "    >\n"
            + "      <libraryjar name=\"${java.home}/lib/rt.jar\"/>\n"
            + "      <libraryjar name=\"${BUILD}/lib/junit.jar\"/>\n"
            + "      <resourcejar name=\"empty\"/>\n"
            + "      <injar name=\"${J2MECLASSES}\"/>\n"
            + "      <keep access=\"public\" type=\"class\" name=\"com.hp.hpl.sparta.Parser\">\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.Reader,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.Reader,com.hp.hpl.sparta.ParseLog,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.io.File,com.hp.hpl.sparta.ParseLog,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.io.File,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(char[],com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "        <!--method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(byte[],com.hp.hpl.sparta.ParseHandler)\"/-->\n"
            + "        <!--method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.InputStream,com.hp.hpl.sparta.ParseLog,com.hp.hpl.sparta.ParseHandler)\"/-->\n"
            + "        <!--method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.InputStream,com.hp.hpl.sparta.ParseHandler)\"/-->\n"
            + "        <!--method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.InputStream,com.hp.hpl.sparta.ParseLog,java.lang.String,com.hp.hpl.sparta.ParseHandler)\"/-->\n"
            + "        <method access=\"public static\"\n"
            + "                type=\"void\"\n"
            + "                name=\"parse(java.lang.String,java.io.Reader,com.hp.hpl.sparta.ParseLog,java.lang.String,com.hp.hpl.sparta.ParseHandler)\"/>\n"
            + "      </keep>\n"
            + "      <keep access=\"public\" type=\"class\" name=\"com.hp.hpl.sparta.Element\">\n"
            + "        <method access=\"public\"\n"
            + "                type=\"java.util.Enumeration\"\n"
            + "                name=\"getAttributeNames()\"/>\n"
            + "      </keep>\n"
            + "    </proguard>\n"
            + "    <delete dir=\"empty\"/>\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"sax-example\" depends=\"jar\">\n"
            + "    <copy todir=\"tmpClasses\" file=\"${CLASSES}/SaxExample.class\"/>\n"
            + "    <copy todir=\"tmpClasses\" file=\"${CLASSES}/Handler.class\"/>\n"
            + "    <java classname=\"SaxExample\">\n"
            + "      <arg value=\"build.xml\"/>\n"
            + "      <classpath>\n"
            + "        <pathelement path=\"tmpClasses\"/>\n"
            + "        <pathelement path=\"lib/sax.jar\"/>\n"
            + "      </classpath>\n"
            + "    </java>\n"
            + "    <delete dir=\"tmpClasses\"/>\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"j2me-sax-example\" depends=\"j2me-jar\">\n"
            + "    <copy todir=\"tmpClasses\" file=\"${J2MECLASSES}/SaxExample.class\"/>\n"
            + "    <copy todir=\"tmpClasses\" file=\"${J2MECLASSES}/Handler.class\"/>\n"
            + "    <java classname=\"SaxExample\"\n"
            + "      jvm=\"java -Xbootclasspath:${J2MEBOOTCLASSPATH}\"\n"
            + "    >\n"
            + "      <arg value=\"build.xml\"/>\n"
            + "      <classpath>\n"
            + "        <pathelement path=\"tmpClasses\"/>\n"
            + "        <pathelement path=\"lib/j2me-sax.jar\"/>\n"
            + "      </classpath>\n"
            + "    </java>\n"
            + "    <delete dir=\"tmpClasses\"/>\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"testers.jar\" depends=\"compile\"\n"
            + "    description=\"Create testers jar file\"\n"
            + "  >\n"
            + "    <mkdir dir=\"${LIB}\"/>\n"
            + "    <jar\n"
            + "      jarfile=\"${BUILD}/lib/testers.jar\"\n"
            + "      basedir=\"${CLASSES}\"\n"
            + "    >\n"
            + "      <include name=\"com/hp/hpl/sparta/test/*.class\"/>\n"
            + "    </jar>\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"dtd\">\n"
            + "    <antstructure output=\"project.dtd\"/>\n"
            + "  </target>\n"
            + "\n"
            + "\n"
            + "  <target name=\"release-bin\" depends=\"-init, jar, javadoc, junit\">\n"
            + "    <property name=\"zipfile-bin\" value=\"${RELEASE}/sparta-bin-${DSTAMP}.zip\"/>\n"
            + "    <property name=\"zipfile-apidoc\" value=\"${RELEASE}/sparta-apidoc-${DSTAMP}.zip\"/>\n"
            + "    <mkdir dir=\"${RELEASE}\"/>\n"
            + "    <delete file=\"${zipfile-bin}\" failonerror=\"no\"/>\n"
            + "    <delete file=\"${zipfile-apidoc}\" failonerror=\"no\"/>\n"
            + "    <zip zipfile=\"${zipfile-bin}\"> \n"
            + "      <zipfileset dir=\".\" prefix=\"sparta\">\n"
            + "        <include name=\"${LIB}/*\"/>\n"
            + "      </zipfileset>\n"
            + "    </zip>\n"
            + "    <zip zipfile=\"${zipfile-apidoc}\"> \n"
            + "      <zipfileset dir=\".\" prefix=\"sparta\">\n"
            + "        <include name=\"${DOC}/**\"/>\n"
            + "      </zipfileset>\n"
            + "    </zip>\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"release-src\" depends=\"-init, jar, javadoc\">\n"
            + "    <property name=\"zipfile-src\" value=\"${RELEASE}/sparta-src-${DSTAMP}.zip\"/>\n"
            + "    <mkdir dir=\"${RELEASE}\"/>\n"
            + "    <delete file=\"${zipfile-src}\" failonerror=\"no\"/>\n"
            + "    <zip zipfile=\"${zipfile-src}\"> \n"
            + "      <zipfileset dir=\".\" prefix=\"sparta\"/>\n"
            + "    </zip>\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"release\"\n"
            + "          depends=\"release-bin, release-src\"/>\n"
            + "\n"
            + "  <target name=\"junit.profile\" depends=\"-init, compile\">\n"
            + "    <java classname=\"SpartaTestSuite\" fork=\"yes\" >\n"
            + "      <classpath>\n"
            + "        <pathelement location=\"${BUILD}/lib/junit.jar\"/>\n"
            + "        <pathelement location=\"${CLASSES}\"/>\n"
            + "      </classpath>\n"
            + "      <arg value=\"-textUI\"/> \n"
            + "      <jvmarg value=\"-Xrunhprof:cpu=times,depth=6\"/> \n"
            + "    </java>\n"
            + "    <!--java classname=\"hat.Main\" fork=\"yes\" >\n"
            + "      <classpath>\n"
            + "        <pathelement location=\"${HAT}/bin/hat.zip\"/>\n"
            + "      </classpath>\n"
            + "      <jvmarg value=\"-mx100m\"/>\n"
            + "      <arg value=\"dump.hprof\"/>\n"
            + "    </java-->\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"junit\" depends=\"-init, jar, testers.jar\"\n"
            + "    description=\"Run regression tests\"\n"
            + "  >\n"
            + "    <property name=\"tout\"           value=\"testReports\"/>\n"
            + "    <delete dir=\"${tout}\" failonerror=\"no\"/>\n"
            + "    <mkdir dir=\"${tout}\"/>\n"
            + "    <mkdir dir=\"${tout}/html\"/>\n"
            + "    <junit fork=\"yes\">\n"
            + "      <classpath>\n"
            + "        <pathelement location=\"${LIB}/thermopylae.jar\"/>\n"
            + "        <pathelement location=\"${BUILD}/lib/testers.jar\"/>\n"
            + "        <pathelement location=\"${BUILD}/lib/junit.jar\"/>\n"
            + "      </classpath>\n"
            + "      <formatter type=\"xml\" />\n"
            + "\n"
            + "      <test todir=\"${tout}\" name=\"com.hp.hpl.sparta.test.SpartaXPathTestCase\"/>\n"
            + "      <test todir=\"${tout}\" name=\"com.hp.hpl.sparta.test.PlainXPathTestCase\"/>\n"
            + "      <test todir=\"${tout}\" name=\"com.hp.hpl.sparta.test.XalanTestCase\"/>\n"
            + "      <test todir=\"${tout}\" name=\"com.hp.hpl.sparta.test.FatPathTestCase\"/>\n"
            + "      <test todir=\"${tout}\" name=\"com.hp.hpl.sparta.test.SAXBuilderTester\"/>\n"
            + "      <test todir=\"${tout}\" name=\"com.hp.hpl.sparta.test.SpartaTestCase\"/>\n"
            + "      <test todir=\"${tout}\"\n"
            + "            name=\"com.hp.hpl.sparta.test.ParseByteStreamTestCase\"/>\n"
            + "    </junit>\n"
            + "    <junitreport todir=\"${tout}\" >\n"
            + "      <fileset dir=\"${tout}\">\n"
            + "        <include name=\"TEST-*.xml\"/>\n"
            + "      </fileset>\n"
            + "      <report todir=\"${tout}/html\"/>\n"
            + "    </junitreport>\n"
            + "    <exec executable=\"${view.html.cmd}\">\n"
            + "      <arg line=\"${view.html.args} ${tout}/html/index.html\"/>\n"
            + "    </exec>\n"
            + "  </target>\n"
            + "\n"
            + "  <target name=\"clean\"\n"
            + "    description=\"Remove intermediate files generated by other targets.\"\n"
            + "  >\n"
            + "    <delete failonerror=\"no\">\n"
            + "      <fileset dir=\"${CLASSES}\" includes=\"**/*.class\"/>\n"
            + "      <fileset dir=\"${J2MECLASSES}\" includes=\"**/*.class\"/>\n"
            + "      <fileset dir=\"${LIB}\" includes=\"**/*.jar\"/>\n"
            + "    </delete>\n"
            + "    <delete dir=\"${DOC}/api\" failonerror=\"no\"/>\n"
            + "  </target>\n"
            + "\n"
            + "</project>\n")
            .getBytes();
}

// $Log: SaxExample.java,v $
// Revision 1.2  2003/07/18 00:05:32  eobrain
// Make compatiblie with J2ME.  For example do not use "new"
// java.util classes.
//
// Revision 1.1  2003/07/01 20:48:02  eobrain
// Example of how to use the SAX part of the API.
//
